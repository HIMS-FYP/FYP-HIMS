<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>DMW Doctor's Version</title>

    <!-- Fonts -->
    <link href="<?php echo e(asset('css/fonts.css')); ?>" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fontawesome.css')); ?>" rel="stylesheet">

    <style>
        .nav-link.active{
            background: #D1F2EB !important;
            border-color:#D1F2EB !important ;
        }

        .current-tab{
            background: #D1F2EB !important;
        }

        .logo-text{
            text-align: center;
            color: #fff;
        }

        .navbar-nav{

            /*background: #ffa23b;*/
        }
        .nav-item-heading{
            border-bottom: 1px solid #fff8b3;
            border-bottom-left-radius: 8px;
            color: #fff;
            padding: 0.2em;
            margin-top: 1em;
            width: 100%;

        }
        .left-menu-link {
            color: #eeeeee !important;
        }
        .visit-holder{
            padding: 2em 2em ;
            background: #D1F2EB;
        }
        .current-visit{
            /*border-left: 5px solid #D4AC0D;*/
            margin: 0.5em;
            padding: 1em;
            border-top-left-radius: 1.4em;
            border-top-right-radius: 1.4em;
            background: #ffffff;
        }
        .encounter-item{
            /*border: 1px solid #aaa;*/
            padding: 0.4em;
            margin-bottom: 1.8em;
        }
        .encounter-heading{
            background: #707B7C;
            color: white;
            padding: 0.4em 0.6em 0.1em 0.6em;
            display: inline-block;
            margin: 0;
            border-top-left-radius: 0.5em;
            border-top-right-radius: 0.5em;
        }
        .encounter-heading-holder{
            border-bottom: 3px solid #707B7C;
        }
        .encounter-body{
            border: 2px solid #707B7C;
            padding: 0.5em;
        }

        .encounter-data{
            margin: 0.2em 0 0.5em 0.5em !important;
        }

        .btn-sm{
            border-radius: 1em;
            padding: 0.1em 1em;
        }

        .investigation-item{
            background: #EAEDED;
            border-left: 6px solid #F4D03F;
            margin: 2.2em 0.5em;
            padding-top: 0.8em;
        }

        .action-button{
            margin: 0.2em 0 0.5em 0.5em;
            padding: 2px 0.8em !important;
            border-radius: 0.8em;
            line-height: 1 !important;
        }

        .encounter-data{
            margin: 0;
            font-size: 1.2em;
        }

        .encounter-data-number{
            border: #3498DB 1px solid;
            padding: 0 0.4em;
            border-radius: 0.5em;
            font-style: normal;
            font-size: 0.9em;
        }

        .investigation-item-caret{
            color: #F4D03F;
            font-size: 1.3em;
        }


        .prescription-item{
            margin: 0;
            font-size: 1.2em;
        }

    </style>

</head>


<body  data-spy="scroll" data-offset="60">

<div id="app">
    <div class="container-fluid">

        <div class="row">

            <!--Left Navigation -->
            <?php echo $__env->make('doctor.components.left-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


            <!--Right Content -->
            <div class="col-lg-9" style="padding-left:0; padding-right: 0;">

                <!-- Top Navigation -->
                <?php echo $__env->make('doctor.components.top_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <main class="py-4">
                    <div class="container-fluid">
                        <div class="row justify-content-center">

                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">Elaine's Wallet</div>

                                    <div class="card-body" >
                                        <?php echo $__env->make('doctor.components.wallet_tabs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                        <!-- VISIT -->
                                        <div class="visit-holder">
                                            <div class="row current-visit" >

                                                <!-- Today's Visit heading -->
                                                <div class="col-12">
                                                    <h2>
                                                        <i class="fa fa-user-md"></i> Today's Visit <?php echo e($accessToken); ?>

                                                    </h2>
                                                    <br />
                                                </div>



                                                <!-- Encounter 1  Chief Complaint / Symptoms-->
                                                <div id="symptom" class="col-12 encounter-item"  >
                                                    <div class="row " >
                                                        <!-- Chief Complaint heading --->
                                                        <div class="col-12 ">
                                                            <div class="encounter-heading-holder">
                                                                <h4 class="encounter-heading">
                                                                    <i class="fa fa-frown"> </i>
                                                                    Chief Complaint / Symptoms
                                                                </h4>
                                                            </div>
                                                        </div>

                                                        <!-- Chief Complaint  body -->
                                                        <div class="col-12 ">
                                                            <div class="encounter-body">
                                                                <div>
                                                                    <?php $__currentLoopData = $encounters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if( $encounter->encounter_code == 001 ): ?>
                                                                            <?php $__currentLoopData = $encounter->encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <p class="encounter-data">
                                                                                    <i class="fa fa-frown-open" style="color: #E74C3C; font-size: 0.9em"> </i>
                                                                                    <?php echo e($encounterData->text_1); ?>

                                                                                </p>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>

                                                                <?php if( $editMode == 'new_symptom'): ?>
                                                                <div>
                                                                    <form action="<?php echo e(route('doctor.user.visit.symptom.save')); ?>"  method="POST">
                                                                        <?php echo e(@csrf_field()); ?>

                                                                        <input type="hidden" name="access_token" value="<?php echo e($accessToken); ?>">
                                                                        <input type="hidden" name="encounter_code" value="001">
                                                                        <input type="hidden" name="encounter_description" value="Chief Complaint/Symptoms">

                                                                        <div class="form-group">
                                                                            <label for="comment">Enter Complaint/Symptom</label>
                                                                            <textarea name="text_1" class="form-control" rows="1" id="comment"></textarea>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <button type="submit" class="btn btn-sm btn-outline-success">
                                                                                <i class="fa fa-save"> </i>
                                                                                Save complaint/Symptom
                                                                            </button>
                                                                        </div>
                                                                    </form>
                                                                </div>

                                                                <?php else: ?>
                                                                <div class="form-group" style="padding: 0.3em">
                                                                    <a  class="btn btn-link"
                                                                        href="<?php echo e(route('doctor.user.visit.symptom.form')); ?>/<?php echo e($accessToken); ?>#symptom">
                                                                        <i class="fa fa-plus-circle"> </i>
                                                                        Add Complaint/Symptom
                                                                    </a>
                                                                </div>
                                                                <?php endif; ?>

                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>


                                                <!-- Encounter 2  Physical examination-->
                                                <div id="examination" class="col-12 encounter-item"  >
                                                    <div class="row " >
                                                        <!--examination heading --->
                                                        <div class="col-12 ">
                                                            <div class="encounter-heading-holder">
                                                                <h4 class="encounter-heading">
                                                                    <i class="fa fa-stethoscope"> </i>
                                                                    Physical examination findings
                                                                </h4>
                                                            </div>
                                                        </div>

                                                        <!-- examination body -->
                                                        <div class="col-12 ">
                                                            <div class="encounter-body">

                                                                <div>
                                                                    <?php $__currentLoopData = $encounters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if( $encounter->encounter_code == 002 ): ?>
                                                                            <?php $__currentLoopData = $encounter->encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <p class="encounter-data">
                                                                                    <i class="fa fa-caret-right"> </i>
                                                                                    <?php echo e($encounterData->text_1); ?>

                                                                                </p>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>

                                                                <?php if( $editMode == 'new_examination'): ?>
                                                                <div>
                                                                    <form action="<?php echo e(route('doctor.user.visit.examination.save')); ?>"  method="POST">
                                                                        <?php echo e(@csrf_field()); ?>

                                                                        <input type="hidden" name="access_token" value="<?php echo e($accessToken); ?>">
                                                                        <input type="hidden" name="encounter_code" value="002">
                                                                        <input type="hidden" name="encounter_description" value="Physical examination">

                                                                        <div class="form-group">
                                                                            <label for="comment">Enter physcial examination findings</label>
                                                                            <textarea name="text_1" class="form-control" rows="1" id="comment"></textarea>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <button type="submit" class="btn btn-sm btn-outline-success">
                                                                                <i class="fa fa-save"> </i>
                                                                                Save findings
                                                                            </button>
                                                                        </div>
                                                                    </form>
                                                                </div>

                                                                <?php else: ?>
                                                                <div class="form-group" style="padding: 0.3em">
                                                                    <a  class="btn btn-link"
                                                                        href="<?php echo e(route('doctor.user.visit.examination.form')); ?>/<?php echo e($accessToken); ?>#examination">
                                                                        <i class="fa fa-plus-circle"> </i>
                                                                        Add Physical examination findings
                                                                    </a>
                                                                </div>
                                                                <?php endif; ?>

                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>

                                                <!-- Encounter 3  Investigations / Lab tests -->
                                                <div id="investigation" class="col-12 encounter-item"  >
                                                    <div class="row " >
                                                        <!--Investigations heading --->
                                                        <div class="col-12 ">
                                                            <div class="encounter-heading-holder">
                                                                <h4 class="encounter-heading">
                                                                    <i class="fa fa-microscope"> </i>
                                                                    Investigations/Lab tests
                                                                </h4>
                                                            </div>
                                                        </div>

                                                        <!-- Investigations body -->
                                                        <div class="col-12 ">
                                                            <div class="encounter-body">
                                                                <!-- Available Datas-->
                                                                <div>
                                                                    <?php $__currentLoopData = $encounters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if( $encounter->encounter_code == 003 ): ?>
                                                                            <?php $__currentLoopData = $encounter->encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <div class="investigation-item" style="padding-bottom: 0.4em">
                                                                                    <!-- Test/Investigation Description -->
                                                                                    <p class="encounter-data">
                                                                                        <i class="fa fa-caret-right investigation-item-caret" > </i>
                                                                                        <i class="encounter-data-number"> #<?php echo e($encounterData->id); ?></i>
                                                                                        <?php echo e($encounterData->text_1); ?>

                                                                                    </p>

                                                                                    <!-- Saved Result -->
                                                                                    <div style="margin: 0.8em;padding: 0.4em; border: #1d68a7 1px dashed">
                                                                                        <b> Saved Results </b>
                                                                                        <?php if( count($encounterData->labResults)<1 ): ?>
                                                                                            <p style="color: #ee4a2f "> No result saved</p>
                                                                                        <?php endif; ?>

                                                                                        <?php $__currentLoopData = $encounterData->labResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <p>
                                                                                                <i class="fa fa-file-alt"> </i>
                                                                                                <?php echo e($labResult->remark); ?>

                                                                                                <a href="#" class=""> View </a>
                                                                                            </p>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </div>
                                                                                </div>

                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>

                                                                <?php if( $editMode == 'new_investigation'): ?>
                                                                <div>
                                                                    <form action="<?php echo e(route('doctor.user.visit.investigation.save')); ?>"  method="POST">
                                                                        <?php echo e(@csrf_field()); ?>

                                                                        <input type="hidden" name="access_token" value="<?php echo e($accessToken); ?>">
                                                                        <input type="hidden" name="encounter_code" value="003">
                                                                        <input type="hidden" name="encounter_description" value="Investigations/Lab tests">

                                                                        <div class="form-group">
                                                                            <label for="comment">Enter physcial examination findings</label>
                                                                            <textarea name="text_1" class="form-control" rows="1" id="comment"></textarea>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <button type="submit" class="btn btn-sm btn-success">
                                                                                <i class="fa fa-save"> </i>
                                                                                Save investigation/test
                                                                            </button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                                <?php else: ?>
                                                                <div class="form-group" style="padding: 0.3em">
                                                                    <a  class="btn btn-link"
                                                                        href="<?php echo e(route('doctor.user.visit.investigation.form')); ?>/<?php echo e($accessToken); ?>#investigation">
                                                                        <i class="fa fa-plus-circle"> </i>
                                                                        Add/Suggest Investigations or Lab tests
                                                                    </a>
                                                                </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>

                                                <!-- Encounter 4 Prescriptions -->
                                                <div id="prescription" class="col-12 encounter-item"  >
                                                    <div class="row " >
                                                        <!--Prescriptions heading --->
                                                        <div class="col-12 ">
                                                            <div class="encounter-heading-holder">
                                                                <h4 class="encounter-heading">
                                                                    <i class="fa fa-pills"> </i>
                                                                    Prescriptions
                                                                </h4>
                                                            </div>
                                                        </div>

                                                        <!-- Prescriptions body -->
                                                        <div class="col-12 ">
                                                            <div class="encounter-body">

                                                                <div>
                                                                    <?php $__currentLoopData = $encounters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if( $encounter->encounter_code == 004 ): ?>
                                                                            <?php $__currentLoopData = $encounter->encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <p class="prescription-item">
                                                                                    <i class="fa fa-capsules"> </i>
                                                                                    <?php echo e($encounterData->text_1); ?>

                                                                                </p>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>

                                                                <?php if( $editMode == 'new_prescription'): ?>
                                                                <div>
                                                                    <form action="<?php echo e(route('doctor.user.visit.prescriptions.save')); ?>"  method="POST">
                                                                        <?php echo e(@csrf_field()); ?>

                                                                        <input type="hidden" name="access_token" value="<?php echo e($accessToken); ?>">
                                                                        <input type="hidden" name="encounter_code" value="004">
                                                                        <input type="hidden" name="encounter_description" value="Prescriptions">

                                                                        <div class="form-group">
                                                                            <label for="comment">Enter Prescription</label>
                                                                            <textarea name="text_1" class="form-control" rows="1" id="comment"></textarea>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <button type="submit" class="btn btn-sm btn-outline-success">
                                                                                <i class="fa fa-save"> </i>
                                                                                Save prescription
                                                                            </button>
                                                                        </div>
                                                                    </form>
                                                                </div>

                                                                <?php else: ?>
                                                                <div class="form-group" style="padding: 0.3em">
                                                                    <a  class="btn btn-link"
                                                                        href="<?php echo e(route('doctor.user.visit.prescriptions.form')); ?>/<?php echo e($accessToken); ?>#prescription">
                                                                        <i class="fa fa-plus-circle"> </i>
                                                                        Add Prescriptions
                                                                    </a>
                                                                </div>
                                                                <?php endif; ?>

                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>

                                                <!-- Encounter 5 Advice  -->
                                                <div id="advice" class="col-12 encounter-item"  >
                                                    <div class="row" >
                                                        <!--Advice heading --->
                                                        <div class="col-12 ">
                                                            <div class="encounter-heading-holder">
                                                                <h4 class="encounter-heading">
                                                                    <i class="fa fa-clipboard-list"> </i>
                                                                    Advice
                                                                </h4>
                                                            </div>
                                                        </div>

                                                        <!-- Advice body -->
                                                        <div class="col-12 ">
                                                            <div class="encounter-body">
                                                                <div>
                                                                    <?php $__currentLoopData = $encounters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if( $encounter->encounter_code == 005 ): ?>
                                                                            <?php $__currentLoopData = $encounter->encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <p class="encounter-data">
                                                                                    <i class="fa fa-check"> </i>
                                                                                    <?php echo e($encounterData->text_1); ?>

                                                                                </p>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>

                                                                <?php if( $editMode == 'new_advice'): ?>
                                                                <div>
                                                                    <form action="<?php echo e(route('doctor.user.visit.advice.save')); ?>"  method="POST">
                                                                        <?php echo e(@csrf_field()); ?>

                                                                        <input type="hidden" name="access_token" value="<?php echo e($accessToken); ?>">
                                                                        <input type="hidden" name="encounter_code" value="005">
                                                                        <input type="hidden" name="encounter_description" value="Advice">

                                                                        <div class="form-group">
                                                                            <label for="comment">Enter Advice</label>
                                                                            <textarea name="text_1" class="form-control" rows="1" id="comment"></textarea>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <button type="submit" class="btn btn-sm btn-outline-success">
                                                                                <i class="fa fa-save"> </i>
                                                                                Save advice
                                                                            </button>
                                                                        </div>
                                                                    </form>
                                                                </div>

                                                                <?php else: ?>
                                                                <div class="form-group" style="padding: 0.3em">
                                                                    <a  class="btn btn-link"
                                                                        href="<?php echo e(route('doctor.user.visit.advice.form')); ?>/<?php echo e($accessToken); ?>#advice">
                                                                        <i class="fa fa-plus-circle"> </i>
                                                                        Add Advice
                                                                    </a>
                                                                </div>
                                                                <?php endif; ?>

                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>

        </div>
    </div>
</div>


<!-- Scripts -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" defer></script>


</body>
</html>
