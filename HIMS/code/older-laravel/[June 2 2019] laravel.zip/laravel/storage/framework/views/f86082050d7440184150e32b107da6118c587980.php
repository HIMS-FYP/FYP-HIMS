
<ul class="nav nav-tabs" role="tablist">


    <li class="nav-item">
        <a class="nav-link <?php echo e($activeWalletTab =="visit"? 'active current-tab':' '); ?> "
           href="<?php echo e(route('hce.patient.consultation.service_form')); ?>/<?php echo e($visit->id); ?>">
            <i class="fa fa-clock"> </i>
            Current Visit
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link <?php echo e($activeWalletTab =="personal"? 'active current-tab':' '); ?>"
           href="<?php echo e(route('expert.user.details.personal')); ?>/<?php echo e($visit->id); ?>">
            <i class="fa fa-user"> </i>
            Personal Details
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e($activeWalletTab =="medical"? 'active current-tab':' '); ?>"
           href="<?php echo e(route('expert.user.medical.background')); ?>/<?php echo e($visit->id); ?>">
            <i class="fa fa-heartbeat"> </i>
            Medical Background
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e($activeWalletTab =="journal"? 'active current-tab':' '); ?> "
           href="#">
            <i class="fa fa-calendar-day"> </i>
            Medical Journal
        </a>
    </li>
</ul>