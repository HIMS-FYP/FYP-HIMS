<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link href="<?php echo e(asset('css/fonts.css')); ?>" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fontawesome.css')); ?>" rel="stylesheet">
    <style>
        .logo-text{
            text-align: center;
            color: #fff;
        }

        .navbar-nav{

            /*background: #ffa23b;*/
        }
        .nav-item-heading{
            border-bottom: 1px solid #fff8b3;
            border-bottom-left-radius: 8px;
            color: #fff;
            padding: 0.2em;
            margin-top: 1em;
            width: 100%;

        }
        .left-menu-link {
            color: #eeeeee !important;
        }

    </style>
</head>
<body>
<div id="app">
    <div class="container-fluid">

        <div class="row">

            <!--Left Navigation -->
            <div class="col-md-3" style="background: #2874A6 !important; min-height: 100vh;  padding-left:0; padding-right: 0; ">

                <div style="padding: 1em; margin-top: 2em">
                    <h2 class="logo-text">
                        <i class="fa fa-wallet"> </i>
                       <b>M-Wallet Reader</b>
                    </h2>
                </div>

                <div style="padding: 1em; " >

                    <h3 class="nav-item-heading">Wallets</h3>
                    <li class="nav-item  list-unstyled">
                        <a class="nav-link left-menu-link" href="#" >
                            <i class="fa fa-wallet"></i>
                            Open a wallet
                        </a>
                    </li>
                    <li class="nav-item   list-unstyled">
                        <a class="nav-link left-menu-link" href="#">
                            <i class="fa fa-clock"></i>
                            History
                        </a>
                    </li>


                    <h3 class="nav-item-heading">Preferences </h3>

                    <li class="nav-item  list-unstyled">
                        <a class="nav-link left-menu-link" href="#">
                            <i class="fa fa-cog"> </i>
                            My Profile
                        </a>
                    </li>
                    <li class="nav-item  list-unstyled">
                        <a class="nav-link left-menu-link " href="#">
                            <i class="fa fa-cog"> </i>
                            Change password
                        </a>
                    </li>
                </div>
            </div>





            <!--Right Content -->
            <div class="col-md-9" style="padding-left:0; padding-right: 0;">

                <!-- Top Navigation -->
                <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
                    <div class="container">
                        
                            
                        
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <!-- Left Side Of Navbar -->
                            <ul class="navbar-nav mr-auto">

                            </ul>

                            <!-- Right Side Of Navbar -->
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        <i class="fa fa-user-circle"> </i> Joanne Meckson
                                    </a>

                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                                            <i class="fa fa-lock-open"> </i> Logout
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>

                <main class="py-4">
                    <div class="container-fluid">
                        <div class="row justify-content-center">

                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">Elaine's Wallet</div>
                                    <div class="card-body">
                                        <?php echo $__env->make('health_employee.doctor.components.wallet_tabs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>

        </div>
    </div>

</div>

<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>


</body>
</html>
