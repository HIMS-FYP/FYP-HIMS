<?php

namespace App\Http\Controllers;

use App\ActiveVisit;
use App\Encounter;
use App\EncounterData;
use App\LabResult;
use App\User;
use App\Visit;
use Illuminate\Http\Request;
use mysql_xdevapi\Result;

class LabController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(){
        $this->middleware('auth:health_care_employee');
    }

    /**
     * Show the application dashboard.
     * @return \Illuminate\Http\Response
     */
    public function index(){
        return redirect()->route('lab.user.visit.search');
    }


    //----------------------------------------------------------------------------------------------
    //-------------------------0.0 Searches------------------------------------------
    public function searchUserByToken(){
        return view('lab.1_search_form')->with(
            [
                'activeWalletTab'=>'visit',
                'editMode'=>'none',
                'accessToken'=>" ",

            ]);
    }

    public function submitSearchQuery(Request $request){
        $visit = $this->visitFromToken($request->input('access_token'));
        $user= User::find($visit->user_id);
        return view('lab.1_search_result')->with(
            [
                'activeWalletTab'=>'visit',
                'editMode'=>'none',
                'user'=>$user,
                'visit'=>$visit,
                'accessToken'=>$request->input('access_token'),
            ]);
    }










    //-------------------------------------------------------------------------------
    //----------------------------HELPERS--------------------------------------------

    #helper Visit from Token
    public function visitFromToken($active_visit_token){
        $activeVisit= ActiveVisit::where('access_token', $active_visit_token )->first();
        $visit = Visit::find($activeVisit->visit_id);
        return $visit;
    }



}
