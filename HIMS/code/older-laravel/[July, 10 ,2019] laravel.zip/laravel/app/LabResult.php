<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LabResult extends Model
{
    //
}
