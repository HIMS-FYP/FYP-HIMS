<?php
/**
 * Created by PhpStorm.
 * User: charden
 * Date: 3/29/2019
 * Time: 20:33 PM
 */

namespace App\DumbClasses;


class Profession
{

}