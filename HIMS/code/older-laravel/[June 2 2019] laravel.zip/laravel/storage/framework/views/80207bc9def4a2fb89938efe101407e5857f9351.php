<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>DMW Accounts</title>

    <!-- Fonts -->
    <link href="<?php echo e(asset('css/fonts.css')); ?>" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fontawesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/widgets.css')); ?>" rel="stylesheet">

    <style>
        .nav-link.active{
            background: #D1F2EB !important;
            border-color:#D1F2EB !important ;
        }

        .logo-text{
            text-align: center;
            color: #fff;
        }

        .navbar-nav{

            /*background: #ffa23b;*/
        }
        .nav-item-heading{
            border-bottom: 1px solid #fff8b3;
            border-bottom-left-radius: 8px;
            color: #fff;
            padding: 0.2em;
            margin-top: 1em;
            width: 100%;

        }
        .left-menu-link {
            color: #eeeeee !important;
        }
        .visit-holder{
            padding: 2em 2em ;
            background: #D1F2EB;
        }
        .current-visit{
            /*border-left: 5px solid #D4AC0D;*/
            margin: 0.5em;
            padding: 1em;
            border-top-left-radius: 1.4em;
            border-top-right-radius: 1.4em;
            background: #ffffff;
        }
        .encounter-item{
            /*border: 1px solid #aaa;*/
            padding: 0.4em;
            margin-bottom: 1.8em;
        }
        .encounter-heading{
            background: #707B7C;
            color: white;
            padding: 0.4em 0.6em 0.1em 0.6em;
            display: inline-block;
            margin: 0;
            border-top-left-radius: 0.5em;
            border-top-right-radius: 0.5em;
        }
        .encounter-heading-holder{
            border-bottom: 3px solid #707B7C;
        }
        .encounter-body{
            border: 2px solid #707B7C;
            padding: 0.5em;
        }
        .btn-sm{
            border-radius: 1em;
            padding: 0.1em 1em;
        }

        .search-container{
            position: relative;
            min-height: 60vh;
            /*border: 1px solid #1d68a7 ;*/
        }

        .search-div {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            min-width: 50vw;
        }

        .fa-search{
            font-size: 1.2em;
            color: #1d68a7;
        }

        .investigation-item{
            background: #EAEDED;
            border-left: 6px solid #F4D03F;
            margin: 2.2em 0.5em;
            padding-top: 0.8em;
        }

        .action-button{
            margin: 0.2em 0 0.5em 0.5em;
            padding: 2px 0.8em !important;
            border-radius: 0.8em;
            line-height: 1 !important;
        }

        .encounter-data{
            margin: 0;
            font-size: 1.2em;
        }

        .encounter-data-number{
            border: #3498DB 1px solid;
            padding: 0 0.4em;
            border-radius: 0.5em;
           font-style: normal;
            font-size: 0.9em;
        }

        .add-form{
           margin-top: 12px;
            border: 1px solid #cccccc;
            padding: 1em;
            background: #f5f5f5;
        }

        .status-paragraph{
            padding: 0;
            margin-bottom: 0;
        }
    </style>

</head>


<body  data-spy="scroll" data-offset="60">

<div id="app">
    <div class="container-fluid">

        <div class="row">

        <?php echo $__env->make('accountant.components.left-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <!--Right Content -->
            <div class="col-lg-9" style="padding-left:0; padding-right: 0;">

                <!-- Top Navigation -->
                <?php echo $__env->make('accountant.components.top_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <!-- Content pane  -->
                <main class="py-4">
                    <div class="container-fluid">
                        <div class="row justify-content-center">

                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <a href="#" class="btn btn-sm btn-danger float-right">
                                            <i class="fa fa-user-times"> </i> Close
                                        </a>
                                    </div>

                                    <div class="card-body" >

                                        <!-- Charges & Expenses -->
                                        <div class="row current-visit" >



                                            <!-- Doctor Visit fee-->
                                            <div id="symptom" class="col-12 encounter-item"  >
                                                <div class="row " >

                                                    <!-- Visit Fee heading--->
                                                    <div class="col-12 ">
                                                        <div class="encounter-heading-holder">
                                                            <h4 class="encounter-heading">
                                                                <i class="fa fa-user-md"> </i>
                                                                Consultation / Visit Fee
                                                            </h4>
                                                        </div>
                                                    </div>

                                                    <!--  Visit Fee   body -->
                                                    <div class="col-12 ">
                                                        <div class="encounter-body">

                                                            <!-- Payment status-->
                                                            <?php if($visit->visit_paid): ?>
                                                            <div>
                                                                 <p class="encounter-data">
                                                                    <i style="color: #E74C3C; font-size: 0.9em"> </i>
                                                                    Visit fee
                                                                     <span class="badge-success badge-custom" style=" font-size: 0.8em">
                                                                        <i class="fa fa-check-circle"> </i> Paid
                                                                     </span>
                                                                     <br/>
                                                                     Fee Amount <strong> <?php echo e($visit->visit_fee); ?> </strong>
                                                                </p>
                                                            </div>
                                                            <?php else: ?>
                                                            <div>
                                                                 <p class="encounter-data">
                                                                    <i style="color: #E74C3C; font-size: 0.9em"> </i>
                                                                    Visit fee
                                                                     <span class="badge-danger badge-custom">
                                                                        <i class="fa fa-exclamation-triangle"> </i> Not paid
                                                                     </span>
                                                                     <br/>
                                                                </p>
                                                            </div>
                                                            <?php endif; ?>


                                                            <?php if( $editMode == "add_payment" ): ?>
                                                            <div class="add-form">
                                                                <form action="<?php echo e(route('accountant.user.fee.visit.save')); ?>"  method="POST">
                                                                        <?php echo e(@csrf_field()); ?>

                                                                        <input type="hidden" name="access_token" value="<?php echo e($accessToken); ?>">

                                                                        <h4> Add Consultation Payment </h4>

                                                                        <div class="input-group" style="margin-bottom: 1em">
                                                                            <div class="input-group-prepend">
                                                                                <span class="input-group-text">Amount</span>
                                                                            </div>

                                                                            <input name="visit_fee" class="form-control"   id="visit_fee" />

                                                                        </div>

                                                                        <div class="form-group">
                                                                            <button type="submit" class="btn btn-sm btn-outline-success">
                                                                                <i class="fa fa-save"> </i>
                                                                                Save payment
                                                                            </button>
                                                                        </div>
                                                                    </form>
                                                            </div>
                                                            <?php else: ?>
                                                            <div class="padded-half">


                                                                <a href="<?php echo e(route('accountant.user.fee.visit.form')); ?>/<?php echo e($accessToken); ?>"
                                                                   class="btn btn-sm btn-primary">
                                                                   <i class="fa fa-plus"> </i>
                                                                    <?php echo e($visit->visit_paid? 'Change' : 'Add'); ?>

                                                                     Payment
                                                                </a>


                                                            </div>
                                                            <?php endif; ?>


                                                        </div>
                                                    </div>

                                                </div>
                                            </div>



                                            <!-- Investigations / Lab tests -->
                                                <div id="investigation" class="col-12 encounter-item"  >
                                                    <div class="row " >
                                                        <!--Investigations/Lab Encounter heading --->
                                                        <div class="col-12 ">
                                                            <div class="encounter-heading-holder">
                                                                <h4 class="encounter-heading">
                                                                    <i class="fa fa-microscope"> </i>
                                                                    Investigations/Lab tests Fees
                                                                </h4>
                                                            </div>
                                                        </div>

                                                        <!-- Investigations/Lab Encounter  body -->
                                                        <div class="col-12 ">
                                                            <div class="encounter-body">
                                                                <!-- Available Investigations/Lab Datas -->
                                                                <div>
                                                                    <?php $__currentLoopData = $encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                              <div id="encounter<?php echo e($encounterData->id); ?>" class="investigation-item" style="padding-bottom: 0.4em">

                                                                                  <!-- Test/Investigation Description -->
                                                                                  <p class="encounter-data">
                                                                                      <i class="fa fa-caret-right" style="color: #F4D03F"> </i>
                                                                                      <i class="encounter-data-number">
                                                                                          Test ID: <b>LB-046-<?php echo e($encounterData->id); ?></b>
                                                                                      </i>
                                                                                      <?php echo e($encounterData->text_1); ?>


                                                                                      <i class="float-right time-stamp">
                                                                                          <?php echo e($encounterData->created_at); ?>

                                                                                          <!-- TODO  Beautiful time -->
                                                                                      </i>
                                                                                  </p>

                                                                                  <!-- PAYMENT STATUS-->
                                                                                  <?php if( $encounterData->is_fee_paid): ?>
                                                                                  <div style="margin-left: 0.8em;padding: 0.4em;">
                                                                                      <b> Status </b>
                                                                                      <p class="status-paragraph">
                                                                                       <span style="color: #38c172 ">  <i class="fa fa-check-circle"></i> Paid ,</span>
                                                                                          <b> Tsh <?php echo e($encounterData->fee_amount); ?> </b>
                                                                                      </p>
                                                                                  </div>
                                                                                  <?php else: ?>
                                                                                  <div style="margin-left: 0.8em;padding: 0.4em;">
                                                                                      <b> Status </b>
                                                                                      <p style="color: #ee4a2f "  class="status-paragraph">
                                                                                         <i class="fa fa-exclamation-triangle"></i>
                                                                                          Not paid
                                                                                          <a class="btn btn-primary action-button"
                                                                                             href="<?php echo e(route('accountant.user.fee.test.form')); ?>/<?php echo e($accessToken); ?>/<?php echo e($encounterData->id); ?>#encounter<?php echo e($encounterData->id); ?>">
                                                                                              <i class="fa fa-plus"></i>
                                                                                              Add Payment
                                                                                          </a>
                                                                                      </p>
                                                                                  </div>
                                                                                  <?php endif; ?>


                                                                                  <!--- ADDING PAYMENT FORM-->
                                                                                  <?php if( $editMode == 'add_test_payment'): ?>
                                                                                      <?php if( $investigationId == $encounterData->id ): ?>
                                                                                          <div style=" margin: 1em !important; padding: 1em; border: 1px solid #aaa">
                                                                                              <h5>
                                                                                                  <i class="fa fa-pencil-alt"> </i>
                                                                                                  Add Payment for <i> <?php echo e($encounterData->text_1); ?>  </i>
                                                                                              </h5>

                                                                                              <form action="<?php echo e(route('accountant.user.fee.test.save')); ?>" method="POST">
                                                                                                  <?php echo e(@csrf_field()); ?>

                                                                                                  <input type="hidden" name="investigation_id" value="<?php echo e($investigationId); ?>">
                                                                                                  <input type="hidden" name="access_token" value="<?php echo e($accessToken); ?>">

                                                                                                  <div class="input-group" style="margin-bottom: 1em">
                                                                                                      <div class="input-group-prepend">
                                                                                                          <span class="input-group-text">Amount</span>
                                                                                                      </div>
                                                                                                      <input name="fee_amount" class="form-control"   id="fee_amount" />
                                                                                                  </div>
                                                                                                  <button type="submit" class="btn btn-sm btn-primary">Save Payment</button>
                                                                                              </form>
                                                                                          </div>
                                                                                      <?php endif; ?>
                                                                                  <?php endif; ?>

                                                                              </div>

                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>


                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>

                                            </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>

        </div>
    </div>
</div>


<!-- Scripts -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" defer></script>


</body>
</html>
