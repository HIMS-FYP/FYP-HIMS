<?php

namespace App\Http\Controllers;

use App\ActiveVisit;
use App\Encounter;
use App\EncounterData;
use App\LabResult;
use App\User;
use App\Visit;
use Illuminate\Http\Request;

class DoctorController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(){
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     * @return \Illuminate\Http\Response
     */
    public function index(){
        return redirect()->route('doctor.user.visit.search');
    }


    //------------------------------------------------------------------------------------
    //-------------------------0.0 Visit Searches---------------------------------------------
    public function searchUserByToken(){
        return view('doctor.1_search_form')->with(
            [
                'activeWalletTab'=>'visit',
                'editMode'=>'none',
                'accessToken'=>" ",

            ]);
    }

    public function submitSearchQuery(Request $request){
        $visit = $this->visitFromToken($request->input('access_token'));
        $user= User::find($visit->user_id);
        return view('doctor.1_search_result')->with(
            [
                'activeWalletTab'=>'visit',
                'editMode'=>'none',
                'user'=>$user,
                'visit'=>$visit,
                'accessToken'=>$request->input('access_token'),
            ]);
    }


    //-------------------------------------------------------------------------------
    //-------------------------1.0 Visits---------------------------------------------
    public function showActiveVisit(Request $request,$access_token){
        $visit = $this->visitFromToken($access_token);
        $encounters = $this->getEncountersWithData($visit->id);

        return view('doctor.2_visit')->with(
            [
                'activeWalletTab'=>'visit',
                'editMode'=>'none',
                'accessToken'=>$access_token,
                'encounters'=>$encounters,
            ]);
    }


    #-------------- 1.1 Visit Symptoms------------------------------------------
    public function showSymptomForm($access_token){
        $visit = $this->visitFromToken($access_token);
        $encounters = $this->getEncountersWithData($visit->id);

        return view('doctor.2_visit')->with(
            [
                'activeWalletTab'=>'visit',
                'editMode'=>'new_symptom',
                'accessToken'=>$access_token,
                'encounters'=>$encounters,
            ]);
    }
    public function saveNewSymptom(Request $request){
        //return $request->all();

        $visit = $this->visitFromToken($request->input('access_token'));

        $encounter = Encounter::firstOrCreate(
                ['visit_id' => $visit->id, 'encounter_code' => $request->input('encounter_code')],
                ['description' => $request->input('encounter_description'), ]
               );

        $encounterData = new EncounterData();
        $encounterData->encounter_id = $encounter->id;
        $encounterData->text_1 =  $request->input('text_1');
        $encounterData->save();


        return redirect()->route('doctor.user.visit.active',[
            'access_token'=>$request->input('access_token'),
            '#symptom'
        ]);
    }

    #-------------- 1.2 Visit Examination------------------------------------------
    public function showExaminationForm($access_token){
        $visit = $this->visitFromToken($access_token);
        $encounters = $this->getEncountersWithData($visit->id);

        return view('doctor.2_visit')->with(
            [
                'activeWalletTab'=>'visit',
                'editMode'=>'new_examination',
                'accessToken'=>$access_token,
                'encounters'=>$encounters,
            ]);
    }
    public function saveNewExamination(Request $request){
        $visit = $this->visitFromToken($request->input('access_token'));

        $encounter = Encounter::firstOrCreate(
            ['visit_id' => $visit->id, 'encounter_code' => $request->input('encounter_code')],
            ['description' => $request->input('encounter_description'), ]
        );

        $encounterData = new EncounterData();
        $encounterData->encounter_id = $encounter->id;
        $encounterData->text_1 =  $request->input('text_1');
        $encounterData->save();


        return redirect()->route('doctor.user.visit.active',[
            'access_token'=>$request->input('access_token'),
            '#examination'
        ]);

    }

    #-------------- 1.3 Visit Investigation------------------------------------------
    public function showInvestigationForm($access_token){
        $visit = $this->visitFromToken($access_token);
        $encounters = $this->getEncountersWithData($visit->id);

        return view('doctor.2_visit')->with(
            [
                'activeWalletTab'=>'visit',
                'editMode'=>'new_investigation',
                'accessToken'=>$access_token,
                'encounters'=>$encounters,
            ]);
    }
    public function saveNewInvestigation(Request $request){
        $visit = $this->visitFromToken($request->input('access_token'));

        $encounter = Encounter::firstOrCreate(
            ['visit_id' => $visit->id, 'encounter_code' => $request->input('encounter_code')],
            ['description' => $request->input('encounter_description'), ]
        );

        $encounterData = new EncounterData();
        $encounterData->encounter_id = $encounter->id;
        $encounterData->text_1 =  $request->input('text_1');
        $encounterData->save();


        return redirect()->route('doctor.user.visit.active',[
            'access_token'=>$request->input('access_token'),
            '#investigation'
        ]);
    }


    #-------------- 1.4 Visit Prescription------------------------------------------
    public function showPrescriptionForm($access_token){
        $visit = $this->visitFromToken($access_token);
        $encounters = $this->getEncountersWithData($visit->id);

        return view('doctor.2_visit')->with(
            [
                'activeWalletTab'=>'visit',
                'editMode'=>'new_prescription',
                'accessToken'=>$access_token,
                'encounters'=>$encounters,
            ]);
    }
    public function saveNewPrescription(Request $request){
        $visit = $this->visitFromToken($request->input('access_token'));

        $encounter = Encounter::firstOrCreate(
            ['visit_id' => $visit->id, 'encounter_code' => $request->input('encounter_code')],
            ['description' => $request->input('encounter_description'), ]
        );

        $encounterData = new EncounterData();
        $encounterData->encounter_id = $encounter->id;
        $encounterData->text_1 =  $request->input('text_1');
        $encounterData->save();

        return redirect()->route('doctor.user.visit.active',[
            'access_token'=>$request->input('access_token'),
            '#prescription'
        ]);

    }

    #-------------- 1.5 Visit Advice------------------------------------------
    public function showAdviceForm($access_token){
        $visit = $this->visitFromToken($access_token);
        $encounters = $this->getEncountersWithData($visit->id);

        return view('doctor.2_visit')->with(
            [
                'activeWalletTab'=>'visit',
                'editMode'=>'new_advice',
                'accessToken'=>$access_token,
                'encounters'=>$encounters,
            ]);
    }
    public function saveNewAdvice(Request $request){

        $visit = $this->visitFromToken($request->input('access_token'));

        $encounter = Encounter::firstOrCreate(
            ['visit_id' => $visit->id, 'encounter_code' => $request->input('encounter_code')],
            ['description' => $request->input('encounter_description'), ]
        );

        $encounterData = new EncounterData();
        $encounterData->encounter_id = $encounter->id;
        $encounterData->text_1 =  $request->input('text_1');
        $encounterData->save();

        return redirect()->route('doctor.user.visit.active',[
            'access_token'=>$request->input('access_token'),
            '#advice'
        ]);

    }




    //------------------------------------------------------------------------------------
    //------------------------- 2.0 BasicInfo---------------------------------------------
    public function userBasicInfo(){
        return view('doctor.b_basic_info')->with(
            [
                'activeWalletTab'=>'basic'
            ]);
    }



    //------------------------------------------------------------------------------------
    //-------------------------3.0 MedicalBackground-------------------------------------
    public function userMedicalBackground(){
        return view('doctor.c_background')->with(
            [
                'activeWalletTab'=>'basic'
            ]);
    }


    //------------------------------------------------------------------------------------
    //-------------------------4.0 Journal-------------------------------------
    public function userJournal(){
        return view('doctor.d_journal')->with(
            [
                'activeWalletTab'=>'journal',
                'editMode'=>'none'
            ]);
    }




    //-------------------------------------------------------------------------------
    //----------------------------HELPERS--------------------------------------------

    #helper Visit from Token
    public function visitFromToken($active_visit_token){
        $activeVisit= ActiveVisit::where('access_token', $active_visit_token )->first();
        $visit = Visit::find($activeVisit->visit_id);
        return $visit;
    }

    #get encounters with EncounterDatas
    public function getEncountersWithData($visit_id){
        $encounters = Encounter::where('visit_id', $visit_id)->get();
        foreach ($encounters as $encounter){
            $encounter->encounterDatas = EncounterData::where('encounter_id',$encounter->id)->get();
            foreach ($encounter->encounterDatas as $encounterData){
                $encounterData->labResults = LabResult::where('investigation_id',$encounterData->id)->get();
            }
        }

        return $encounters;
    }

}
