<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

//----------------------------------------0.0 USER -------------------=============================-----
//--------------------------------------------------------------------=============================-----
#======Visit============================================================================================
Route::get('/user', 'UserController@index')->name('user');

Route::get('/user/visit/current/', 'UserController@currentVisit')->name('user.visit.current');
Route::get('/user/visit/add', 'UserController@addNewVisit')->name('user.visit.add');
Route::get('/user/visit/close', 'UserController@closeVisitForm')->name('user.visit.close');

Route::get('/user/visit/previous', 'UserController@showPreviousVisits')->name('user.visit.previous.list');
Route::get('/user/visit/previous/{visit_id?}', 'UserController@activatePreviousVisits')->name('user.visit.previous.activate');


Route::get('/user/info/basic', 'UserController@userBasicInfo')->name('user.info.basic');
Route::get('/user/info/background', 'UserController@userBasicInfo')->name('user.background');
Route::get('/user/info/journal', 'UserController@userBasicInfo')->name('user.journal');










//----------------------------------------------------------------------------------------------------------
//------------------------- 2.0 DOCTOR -----------------------------------------------------------------------
Route::get('/doctor', 'DoctorController@index')->name('doctor');

//Search Visit
Route::get('/doctor/user/visit/search', 'DoctorController@searchUserByToken')->name('doctor.user.visit.search');
Route::post('/doctor/user/visit/search/submit', 'DoctorController@submitSearchQuery')->name('doctor.user.visit.search.submit');


//Visits
Route::get('/doctor/user/visit/active/{access_token?}', 'DoctorController@showActiveVisit')->name('doctor.user.visit.active');

Route::get('/doctor/user/visit/symptom/add/{access_token?}', 'DoctorController@showSymptomForm')->name('doctor.user.visit.symptom.form');
Route::post('/doctor/user/visit/symptom/save', 'DoctorController@saveNewSymptom')->name('doctor.user.visit.symptom.save');

Route::get('/doctor/user/visit/examination/add/{access_token?}', 'DoctorController@showExaminationForm')->name('doctor.user.visit.examination.form');
Route::post('/doctor/user/visit/examination/save', 'DoctorController@saveNewExamination')->name('doctor.user.visit.examination.save');

Route::get('/doctor/user/visit/investigation/add/{access_token?}', 'DoctorController@showInvestigationForm')->name('doctor.user.visit.investigation.form');
Route::post('/doctor/user/visit/investigation/save', 'DoctorController@saveNewInvestigation')->name('doctor.user.visit.investigation.save');

Route::get('/doctor/user/visit/prescriptions /add/{access_token?}', 'DoctorController@showPrescriptionForm')->name('doctor.user.visit.prescriptions.form');
Route::post('/doctor/user/visit/prescriptions /save', 'DoctorController@saveNewPrescription')->name('doctor.user.visit.prescriptions.save');

Route::get('/doctor/user/visit/advice/add/{access_token?}', 'DoctorController@showAdviceForm')->name('doctor.user.visit.advice.form');
Route::post('/doctor/user/visit/advice/save', 'DoctorController@saveNewAdvice')->name('doctor.user.visit.advice.save');


//Medical Background
Route::get('/doctor/user/info/background', 'DoctorController@userMedicalBackground')->name('doctor.user.background');

//Journal
Route::get('/doctor/user/info/journal', 'DoctorController@userJournal')->name('doctor.user.journal');

//Ifo
Route::get('/doctor/user/info/basic', 'DoctorController@userBasicInfo')->name('doctor.user.info.basic');


//------------------------- 2.0DOCTOR --------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------




//----------------------------------------------------------------------------------------------------------------------
//------------------------- 3.0 LAB ------------------------------------------------------------------------------------

Route::get('/lab', 'LabController@index')->name('lab');

Route::get('/lab/user/visit/search', 'LabController@searchUserByToken')->name('lab.user.visit.search');
Route::post('/lab/user/visit/search/submit', 'LabController@submitSearchQuery')->name('lab.user.visit.search.submit');

//Investigations
Route::get('/lab/user/investigations/{access_token?}', 'LabController@showActiveInvestigations')->name('lab.user.investigations.active');

//Results
Route::get('/lab/user/results/form/{access_token?}/{investigation_id?}', 'LabController@showResultForm')->name('lab.user.result.form');
Route::post('/lab/user/results/save', 'LabController@saveResult')->name('lab.user.result.save');

