<?php

namespace App\Http\Controllers;

use App\DumbClasses\Profession;
use App\Events\HealthCareEmployeeAdded;
use App\HealthCareEmployee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class HealthCareProviderController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(){
        $this->middleware('auth:health_care_provider');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){
        return redirect()->route('health_provider.employees',[
            'active_tab'=>'doctors',
        ]);
    }

    public function showEmployees($active_tab ){

        $healthCareEmployees = HealthCareEmployee::role($this->getProfession( $active_tab )->role)
                                ->get();

        return view('health_provider.staff',[
            'healthCareEmployees'=>$healthCareEmployees,
            'activeTab'=>$active_tab,
            'editMode'=>"none",
            'profession'=>$this->getProfession($active_tab)->sentenceCase,
        ]);
    }

    public function showAddEmployeeForm($active_tab){
        return view('health_provider.staff',[
            'activeTab'=>$active_tab,
            'editMode'=>"new_doctor",
            'profession'=>$this->getProfession($active_tab)->sentenceCase,
        ]);
    }

    public function saveNewEmployee(Request $request){

        $request->validate([
            'name' => 'required|max:169',
            'email' => 'required|unique:health_care_employees|max:169',
            'phone' => 'required|max:28',

            'employment_id' => 'required|max:169',

            'qualification' => 'required|max:169',
            'specialization' => 'required|max:169',

        ]);



        $data = $request->all();

        //TODO Validate

        $defaultPassword= str_random(10);

        $healCareEmployee = HealthCareEmployee::create([
            'health_provider_id' => Auth::id(),
            'profession' => $this->getProfession( $request->input('active_tab') )->role ,
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($defaultPassword),

            'phone' => $data['phone'],
            'employment_id' => $data['employment_id'],

            'qualification' => $data['qualification'],
            'specialization' => $data['specialization'],
        ]);

        $healCareEmployee->plain_password = $defaultPassword; //For sending with email

        //ROLE
        $healCareEmployee->assignRole($this->getProfession( $request->input('active_tab') )->role);

        //Grant selected permissions
       if($request->has('view_basic_info')) {  $healCareEmployee->givePermissionTo('view_basic_info'); }
       if($request->has('view_medical_background')) {  $healCareEmployee->givePermissionTo('view_medical_background'); }
       if($request->has('update_medical_background')) {  $healCareEmployee->givePermissionTo('update_medical_background'); }
       if($request->has('view_medical_journal')) {  $healCareEmployee->givePermissionTo('view_medical_journal'); }

       if($request->has('add_symptoms')) {  $healCareEmployee->givePermissionTo('add_symptoms'); }
       if($request->has('view_symptoms')) {  $healCareEmployee->givePermissionTo('view_symptoms'); }
       if($request->has('recommend_test')) {  $healCareEmployee->givePermissionTo('recommend_test'); }
       if($request->has('view_recommended_test')) {  $healCareEmployee->givePermissionTo('view_recommended_test'); }
       if($request->has('add_test_result')) {  $healCareEmployee->givePermissionTo('add_test_result'); }

       if($request->has('add_prescription')) {  $healCareEmployee->givePermissionTo('add_prescription'); }
       if($request->has('view_prescription')) {  $healCareEmployee->givePermissionTo('view_prescription'); }
       if($request->has('issue_medicine')) {  $healCareEmployee->givePermissionTo('issue_medicine'); }
       if($request->has('view_issued_medicine')) {  $healCareEmployee->givePermissionTo('view_issued_medicine'); }

       if($request->has('verify_consultation_fee')) {  $healCareEmployee->givePermissionTo('verify_consultation_fee'); }
       if($request->has('check_consultation_fee')) {  $healCareEmployee->givePermissionTo('check_consultation_fee'); }
       if($request->has('verify_lab_fee')) {  $healCareEmployee->givePermissionTo('verify_lab_fee'); }
       if($request->has('check_lab_fee')) {  $healCareEmployee->givePermissionTo('check_lab_fee'); }
       if($request->has('verify_medicine_fee')) {  $healCareEmployee->givePermissionTo('verify_medicine_fee'); }
       if($request->has('check_medicine_fee')) {  $healCareEmployee->givePermissionTo('check_medicine_fee'); }

        //TODO send invitation email
        event(new HealthCareEmployeeAdded($healCareEmployee));

        return redirect()->route('health_provider.employees',[
            'active_tab'=>$request->input('active_tab'),
        ]);

    }

    public function updateEmployee(Request $request){
        return view('health_provider.staff',[
            'activeTab'=>'doctors',
            'search'=>true,
        ]);
    }



    //---------------------------------------------------------------
    //-------------------------HELPERS-------------------------------
    private function getProfession($activeTab){
        $profession = new Profession();

        switch ($activeTab){
            case 'doctors';{
                $profession->sentenceCase = "Doctor";
                $profession->role = "doctor";
                return  $profession;
            }break;

             case 'nurses';{
                 $profession->sentenceCase = "Nurse";
                 $profession->role = "nurse";
                 return  $profession;
            }break;

             case 'labs';{
                 $profession->sentenceCase = "Lab Technician";
                 $profession->role = "lab";
                 return  $profession;
            }break;

             case 'pharmacists';{
                 $profession->sentenceCase = "Pharmacist";
                 $profession->role = "pharmacist";
                 return  $profession;
            }break;

             case 'receptionists';{
                 $profession->sentenceCase = "Receptionist";
                 $profession->role = "receptionist";
                 return  $profession;
            }break;
         }

         return $profession;
    }





    #--------------- STAFF ----------------------------------
    public function showSearchFacilityForm( ){
        return view('health_provider.auth.login',[
            'activeTab'=>'staff',
            'search'=>true,
        ]);
    }

    public function searchFacility(Request $request){
        return view('health_provider.auth.login',[
            'activeTab'=>'staff',
            'search'=>true,
        ]);
    }



    public function showStaffLoginForm($activeTab){
        return view('health_provider.auth.login',[
            'activeTab'=>$activeTab,
            'search'=>true,
        ]);
    }




}
