<?php

namespace App\Http\Controllers;

use App\ActiveVisit;
use App\Encounter;
use App\EncounterData;
use App\LabResult;
use App\User;
use App\Visit;
use Illuminate\Http\Request;
use mysql_xdevapi\Result;

class LabController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(){
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     * @return \Illuminate\Http\Response
     */
    public function index(){
        return redirect()->route('lab.user.visit.search');
    }


    //----------------------------------------------------------------------------------------------
    //-------------------------0.0 Searches------------------------------------------
    public function searchUserByToken(){
        return view('lab.1_search_form')->with(
            [
                'activeWalletTab'=>'visit',
                'editMode'=>'none',
                'accessToken'=>" ",

            ]);
    }

    public function submitSearchQuery(Request $request){
        $visit = $this->visitFromToken($request->input('access_token'));
        $user= User::find($visit->user_id);
        return view('lab.1_search_result')->with(
            [
                'activeWalletTab'=>'visit',
                'editMode'=>'none',
                'user'=>$user,
                'visit'=>$visit,
                'accessToken'=>$request->input('access_token'),
            ]);
    }



    //----------------------------------------------------------------------------------------------
    //-------------------------1.0 Investigations --------------------------------------------------
    public function showActiveInvestigations($access_token){
        $visit = $this->visitFromToken($access_token);
        $encounterDatas = $this->getEncounterDatas($visit->id);

        return view('lab.2_investigations')->with(
            [
                'editMode'=>'none',
                'accessToken'=>$access_token,
                'encounterDatas'=>$encounterDatas,
                'investigationId'=>" ",
            ]);
    }



     public function showResultForm($access_token, $investigation_id){
        $visit = $this->visitFromToken($access_token);
        $encounterDatas = $this->getEncounterDatas($visit->id);

        return view('lab.2_investigations')->with(
            [
                'editMode'=>'add_result',
                'accessToken'=>$access_token,
                'encounterDatas'=>$encounterDatas,
                'investigationId'=>$investigation_id,
            ]);
    }

     public function saveResult(Request $request){

        $labResult = new LabResult();
        //TODO MOVE File to storage
        $labResult->investigation_id = $request->input('investigation_id');
        $labResult->file_path = $request->input('result_file');
        $labResult->remark = $request->input('result_remark');
        $labResult->save();

        return redirect()->route('lab.user.investigations.active',
                   [ 'access_token'=>$request->input('access_token')]
             );
    }






    //-------------------------------------------------------------------------------
    //----------------------------HELPERS--------------------------------------------

    #helper Visit from Token
    public function visitFromToken($active_visit_token){
        $activeVisit= ActiveVisit::where('access_token', $active_visit_token )->first();
        $visit = Visit::find($activeVisit->visit_id);
        return $visit;
    }

    #get encounterDatas with EncounterDatas
    public function getEncounterDatas($visit_id){
        $encounter = Encounter::where('visit_id', $visit_id)->where('encounter_code', 003)->first();
        $encounterDatas =  EncounterData::where('encounter_id',$encounter->id)->get();
        foreach ($encounterDatas as $encounterData){
            $encounterData->labResults = LabResult::where('investigation_id',$encounterData->id)->get();
        }
        return $encounterDatas;
    }

}
