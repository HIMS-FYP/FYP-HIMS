<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>DMW | Doctor</title>

    <!-- Fonts -->
    <link href="<?php echo e(asset('css/fonts.css')); ?>" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fontawesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/widgets.css')); ?>" rel="stylesheet">

    <style>
        .nav-link.active{
            background: #D1F2EB !important;
            border-color:#D1F2EB !important ;
        }

        .current-tab{
            background: #D1F2EB !important;
        }

        .logo-text{
            text-align: center;
            color: #fff;
        }

        .navbar-nav{

            /*background: #ffa23b;*/
        }
        .nav-item-heading{
            border-bottom: 1px solid #fff8b3;
            border-bottom-left-radius: 8px;
            color: #fff;
            padding: 0.2em;
            margin-top: 1em;
            width: 100%;

        }
        .left-menu-link {
            color: #eeeeee !important;
        }
        .visit-holder{
            padding: 2em 2em ;
            background: #D1F2EB;
        }
        .current-visit{
            /*border-left: 5px solid #D4AC0D;*/
            margin: 0.5em;
            padding: 1em;
            border-top-left-radius: 1.4em;
            border-top-right-radius: 1.4em;
            background: #ffffff;
        }
        .encounter-item{
            /*border: 1px solid #aaa;*/
            padding: 0.4em;
            margin-bottom: 1.8em;
        }
        .encounter-heading{
            background: #707B7C;
            color: white;
            padding: 0.4em 0.6em 0.1em 0.6em;
            display: inline-block;
            margin: 0;
            border-top-left-radius: 0.5em;
            border-top-right-radius: 0.5em;
        }
        .encounter-heading-holder{
            border-bottom: 3px solid #707B7C;
        }
        .encounter-body{
            border: 2px solid #707B7C;
            padding: 0.5em;
        }

        .encounter-data{
            margin: 0.2em 0 0.5em 0.5em !important;
        }

        .btn-sm{
            border-radius: 1em;
            padding: 0.1em 1em;
        }

        .investigation-item{
            background: #EAEDED;
            border-left: 6px solid #F4D03F;
            margin: 2.2em 0.5em;
            padding-top: 0.8em;
        }

        .action-button{
            margin: 0.2em 0 0.5em 0.5em;
            padding: 2px 0.8em !important;
            border-radius: 0.8em;
            line-height: 1 !important;
        }

        .encounter-data{
            margin: 0;
            font-size: 1.2em;
        }

        .encounter-data-number{
            border: #3498DB 1px solid;
            padding: 0 0.4em;
            border-radius: 0.5em;
            font-style: normal;
            font-size: 0.9em;
        }

        .investigation-item-caret{
            color: #F4D03F;
            font-size: 1.3em;
        }

        .add-form{
            margin: 1em 4em !important;
            padding: 1em;
            border: 1px solid #aaa;
           <?php echo e($activeTab=='insurance'? ' background: #85C1E9': ' background: #fff8b3'); ?> ;
        }


        .accounts-active-tab{
            border: 1px solid #dddddd;
        }

        .user-result-item{
             background: #f0e68c;
             display: inline-block;
            padding: 0.6em 2em;
            border-radius: 1em ;
        }
    </style>

</head>


<body  data-spy="scroll" data-offset="60">

<div id="app">
    <div class="container-fluid">

        <div class="row">

            <!--Left Navigation -->
            <?php echo $__env->make('health_employee.components.left-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


            <!--Right Content -->
            <div class="col-lg-9" style="padding-left:0; padding-right: 0;">

                <!-- Top Navigation -->
                <?php echo $__env->make('health_employee.components.top_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <main class="py-4">
                        <div class="row justify-content-center" style="padding: 1em">
                            <div class="col-md-12" >
                                <div class="card" >

                                    <div class="card-body"  >

                                        <!-- OPD forms TABS -->
                                        <div class="tabs-wrapper"  >
                                            <ul class="nav nav-tabs ">
                                                <li class="nav-item <?php echo e($activeTab=='insurance'? 'accounts-active-tab': ' '); ?>">
                                                    <a class="nav-link  "
                                                       href="<?php echo e(route('hce.opd')); ?>/insurance">
                                                        <i class="fa fa-user-md"> </i>
                                                        OPD NHIF-Forms
                                                    </a>
                                                </li>

                                                <li class="nav-item <?php echo e($activeTab=='cash'? 'accounts-active-tab': ' '); ?>">
                                                    <a class="nav-link  "
                                                       href="<?php echo e(route('hce.opd')); ?>/cash">
                                                        <i class="fa fa-user-md"> </i>
                                                        OPD Cash-Forms
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>



                                        <div class="content-wrapper">
                                            <div class="list-wrapper" style="padding: 1em">

                                                <!-- VERIFY Wallet Form -->
                                                <?php if( $editMode=='verify_dmw'): ?>
                                                    <form method="POST" action="<?php echo e(route('hce.opd.dmw.verify.attempt')); ?>" >

                                                        <?php echo e(@csrf_field()); ?>

                                                        <input name="active_tab" type="hidden" value="<?php echo e($activeTab); ?>">

                                                        <div class="card col-md-10 offset-1 add-form">
                                                            <div class="card-body">
                                                                <div>  <!-- Validation Errors -->
                                                                    <?php if($errors->any()): ?>
                                                                        <div class="alert alert-danger">
                                                                            <ul>
                                                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <li style="list-style: none">
                                                                                        <i class="fa fa-user-times"> </i>
                                                                                        <?php echo e($error); ?>

                                                                                    </li>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </ul>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                </div>

                                                                <!--1.0  DMW ID FORM-->
                                                                <div class="form-group row">

                                                                    <div class="input-group mb-3">
                                                                        <div class="input-group-prepend">
                                                                            <span class="input-group-text">Wallet ID</span>
                                                                        </div>
                                                                        <input  name="dmw_id"
                                                                                value="<?php echo e(isset($user->dmw_id) ? $user->dmw_id : old('dmw_id')); ?>"
                                                                                type="text" class="form-control" >
                                                                        <div class="input-group-append">
                                                                            <button type="submit" class="input-group-text">
                                                                                <span >GO</span>
                                                                            </button>

                                                                        </div>

                                                                    </div>

                                                                </div>

                                                                <?php if( $results ==  true ): ?>
                                                               <div class="user-result-item">
                                                                   <h4>
                                                                       <i class="fa fa-user-shield"> </i>
                                                                       Confirm Holder
                                                                   </h4>

                                                                            <li style="list-style: none">
                                                                               <i class="fa fa-user"> </i>
                                                                               <?php echo e($user->name); ?>

                                                                           </li>
                                                                           <li style="list-style: none">
                                                                               <i class="fa fa-phone"> </i>
                                                                               <?php echo e($user->phone); ?>

                                                                           </li>
                                                                           <li style="list-style: none">
                                                                               <i class="fa fa-calendar-day"> </i>
                                                                               <?php echo e($user->dob); ?>

                                                                           </li>

                                                                           <li style="list-style: none">
                                                                               <a class="btn btn-sm btn-success"
                                                                                    href="<?php echo e(route('hce.opd.form.generate')); ?>/<?php echo e($user->dmw_id); ?>/<?php echo e($activeTab); ?>">
                                                                                  <i class="fa fa-check-double"> </i>
                                                                                   Confirm
                                                                               </a>
                                                                           </li>
                                                               </div>
                                                                <?php endif; ?>

                                                                <!-- DMW result -->
                                                                <div>

                                                                </div>
                                                            </div>

                                                        </div>

                                                    </form>
                                                <?php endif; ?>
                                              <!-- END VERIFY Wallet Form -->



                                                <!-- New VISIT Form -->
                                                <?php if( $editMode=='new_form'): ?>
                                                    <form method="POST" action="<?php echo e(route('hce.opd.form.save')); ?>" >

                                                        <?php echo e(@csrf_field()); ?>

                                                        <input name="active_tab" type="hidden" value="<?php echo e($activeTab); ?>">

                                                        <div class="card col-md-10 offset-1 add-form">

                                                            <div>
                                                                <h4>
                                                                    <i class="fa fa-file-medical"> </i>
                                                                    New Form
                                                                    <a class="btn btn-sm btn-danger float-right"
                                                                       href="<?php echo e(route('hce.opd')); ?>/<?php echo e($activeTab); ?>">
                                                                        <i class="fa fa-times-circle"> </i>  Cancel
                                                                    </a>
                                                                </h4>
                                                            </div>

                                                            <div class="card-body">

                                                                <!--Validation Errors-->
                                                                <div>
                                                                    <?php if($errors->any()): ?>
                                                                        <div class="alert alert-danger">
                                                                            <ul>
                                                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <li style="list-style: none">
                                                                                        <i class="fa fa-user-times"> </i>
                                                                                        <?php echo e($error); ?>

                                                                                    </li>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </ul>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <!-- END Validation Errors-->



                                                                <!--1.0 NHIF Card Number -->
                                                                <div class="form-group row">
                                                                    <label for="nhif_card_number" class="col-md-8 col-form-label text-md-right">
                                                                        <h4> Wallet ID <strong><?php echo e($dmw_id); ?> </strong>
                                                                            <a class="btn btn-sm btn-warning"
                                                                                href="<?php echo e(route('hce.opd.dmw.verify.form')); ?>/<?php echo e($activeTab); ?>">
                                                                                Change
                                                                                <i class="fa fa-pencil-alt"></i>
                                                                            </a>
                                                                        </h4>
                                                                    </label>
                                                                    <input name="dmw_id" type="hidden" value="<?php echo e($dmw_id); ?>">
                                                                </div>


                                                                <!--1.0 Wallet Access Code -->
                                                                <div class="form-group row">
                                                                    <label for="nhif_card_number" class="col-md-3 col-form-label text-md-right">
                                                                        Wallet Access Code
                                                                    </label>

                                                                    <div class="col-md-8">
                                                                        <input  type="text" class="form-control"
                                                                               placeholder=" "
                                                                               name="wallet_access_code" value="<?php echo e(old('wallet_access_code')); ?>" required autofocus>
                                                                    </div>
                                                                </div>


                                                                <!--1.0 NHIF Card Number -->
                                                                <div class="form-group row">
                                                                    <label for="nhif_card_number" class="col-md-3 col-form-label text-md-right">
                                                                        NHIF Card No
                                                                    </label>

                                                                    <div class="col-md-8">
                                                                        <input  type="text" class="form-control"
                                                                               placeholder=" "
                                                                               name="nhif_card_number" value="<?php echo e(old('nhif_card_number')); ?>" required autofocus>
                                                                    </div>
                                                                </div>

                                                                <!--1.1 Consultation Fee -->
                                                                <div class="form-group row">
                                                                    <label for="consultation_fee" class="col-md-3 col-form-label text-md-right">
                                                                        Consultation Fee
                                                                    </label>

                                                                    <div class="col-md-8">
                                                                        <input type="text" class="form-control"
                                                                               placeholder=" "
                                                                               name="consultation_fee" value="<?php echo e(old('consultation_fee')); ?>" required autofocus>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="card-footer">
                                                                <div class="form-group row mb-0">
                                                                    <div class="col-md-8 offset-md-2">
                                                                        <button type="submit" class="btn btn-primary" style="width: 100%">
                                                                            Done
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </form>
                                                <?php endif; ?>
                                               <!-- END New VISIT Form -->



                                                <!-- LIST -->
                                                <div>
                                                    <!-- New Form Generate-Button -->
                                                    <div>
                                                        <a class="btn <?php echo e($activeTab=='insurance'? 'btn-primary ': 'btn-warning'); ?>"
                                                            href="<?php echo e(route('hce.opd.dmw.verify.form')); ?>/<?php echo e($activeTab); ?>"
                                                             style="color: #fff; margin: 0.5em">
                                                            <i class="fa fa-file-medical"></i>
                                                            Generate
                                                            <?php echo e($activeTab=='insurance'? 'NHIF': 'Cash'); ?>

                                                            Form
                                                        </a>
                                                    </div>

                                                    <!-- List of Opd Forms -->
                                                    <table class="table">
                                                        <thead>
                                                        <tr>
                                                            <th>Date</th>
                                                            <th>Holder Name</th>
                                                            <th>Temporal Access Token</th>
                                                            <th>Action</th>
                                                             <th> </th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>

                                                        <?php $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $class = $i%2 == 0 ? 'table-success' : 'table-warning'; ?>
                                                            <tr class="<?php echo e($class); ?>">
                                                                <td> <?php echo e($visit->created_at); ?></td>
                                                                <td> <?php echo e($visit->name); ?></td>
                                                                 <td class="code-font"> <?php echo e($visit->access_token); ?> </td>
                                                                 <td>
                                                                    <a class="btn btn-sm btn-outline-primary">
                                                                        view
                                                                    </a>
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </tbody>
                                                    </table>
                                                </div>
                                                <!-- END LIST -->


                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                </main>
            </div>

        </div>
    </div>
</div>


<!-- Scripts -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" defer></script>


</body>
</html>
