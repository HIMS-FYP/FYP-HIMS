
<ul class="nav nav-tabs" role="tablist">
    <li class="nav-item">
        <a class="nav-link <?php echo e($activeWalletTab =="visit"? 'active':' '); ?> "
           href="<?php echo e(route('user.visit.current')); ?>">
            <i class="fa fa-user-md"> </i>
            Current Visit
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link <?php echo e($activeWalletTab =="basic"? 'active':' '); ?> "
           href="<?php echo e(route('user.info.basic')); ?>">
            <i class="fa fa-user"> </i>
            Basic Information
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link"  href="<?php echo e(route('user.background')); ?>">
            <i class="fa fa-heartbeat"> </i>
            Medical Background
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e($activeWalletTab =="journal"? 'active':' '); ?> "
           href="<?php echo e(route('user.journal')); ?>">
            <i class="fa fa-calendar-day"> </i>
            Medical Journal
        </a>
    </li>
</ul>