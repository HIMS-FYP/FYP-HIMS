<?php

namespace App\Http\Controllers;

use App\ActiveVisit;
use App\Allergy;
use App\BloodRelative;
use App\Contact;
use App\DumbClasses\Parameters;
use App\Encounter;
use App\EncounterData;
use App\Immunization;
use App\JournalRecord;
use App\LabResult;
use App\MedicalCondition;
use App\Medication;
use App\User;
use App\Visit;
use App\VitalSign;
use App\VitalSignValue;
use App\Weight;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;

class UserControllerAPI extends Controller{

    /**
     * Create a new controller instance.
     * @return void
     */
    public function __construct(){
      //  $this->middleware('auth');
    }


    /**
     * Show the application dashboard.
     * @return \Illuminate\Http\Response
     */
    public function index(){
        return redirect()->route('user.visits');
    }



    #1.2 Vital Signs
    public function getVitalSignRecords($user_id, $vs_id){

         $vitalSignValues = VitalSignValue::where('user_id', $user_id)
            ->where('vital_sign_id', $vs_id)
            ->where('active', true)
            ->orderBy('id', 'DESC')
            ->get();

        return response()->json([
            'status'=>'success',
            'data'=> $vitalSignValues
        ]);

    }


    public function saveNewVitalSignRecord(Request $request){
        VitalSignValue::create([
            'vital_sign_id'=> $request->input('vital_sign_id'),
            'user_id'=>$request->input('user_id'),
            'value'=>$request->input('vs_value'),
            'active'=>true,
        ]);

        return  response()->json([
            'status'=>'success',
         ]);
    }





    #1.2 medications
    public function getMedications($user_id){
        $medication = Medication::where('user_id',$user_id )->orderBy('id','DESC')->get();
        return response()->json([
            'status'=>'success',
            'data'=> $medication
        ]);
    }

    public function saveMedications(Request $request){

        $medication= new Medication();
        $medication->user_id = $request->input('user_id');
        $medication->name = $request->input('name');
        $medication->taken_for = $request->input('taken_for');
        $medication->started_at = $request->input('started_at');
        $medication->results = $request->input('results');
        $medication->ended_at ="N/A";
        $medication->instruction ="N/A";
        $medication->intake_method = "N/A";
        $medication->notes = "N/A";
        $medication->save();

        //Add Journal record for traversing
        $journalRecord = new JournalRecord();
        $journalRecord->user_id =$request->input('user_id');
        $journalRecord->table_name = "medication";
        $journalRecord->item_id = $medication->id;
        $journalRecord->save();

        return response()->json([
            'status'=>'success'
         ]);
    }

    #1.3 allergies
    public function getAllergies($user_id){
        $allergies = Allergy::where('user_id', $user_id)
            ->orderBy('id','DESC')->get();

        return response()->json([
            'status'=>'success',
            'data'=> $allergies
        ]);
    }

    public function saveNewAllergy(Request $request){
        $allergy= new Allergy();
        $allergy->user_id = $request->input('user_id');
        $allergy->name = $request->input('name');
        $allergy->reaction = $request->input('reaction');
        $allergy->severity = $request->input('severity');
        $allergy->notes = "N/A";
        $allergy->save();

        //Add Journal record for traversing
        $journalRecord = new JournalRecord();
        $journalRecord->user_id = $allergy->user_id;
        $journalRecord->table_name = "allergy";
        $journalRecord->item_id = $allergy->id;
        $journalRecord->save();

        return response()->json([
            'status'=>'success',
         ]);
    }

    #1.4 immunizations
    public function getImmunizations($user_id){
        $immunizations = Immunization::where('user_id', $user_id )
            ->orderBy('id','DESC')->get();

        return response()->json([
            'status'=>'success',
            'data'=> $immunizations
        ]);
    }

    public function saveNewImmunization(Request $request){

        $immunization= new Immunization();
        $immunization->user_id = $request->input('user_id');
        $immunization->name = $request->input('name');
        $immunization->prescribed_for = $request->input('prescribed_for');
        $immunization->dosage = "N/A";
        $immunization->completed_at ="N/A";
        $immunization->save();

        //Add Journal record for traversing
        $journalRecord = new JournalRecord();
        $journalRecord->user_id =  $immunization->user_id;
        $journalRecord->table_name = "immunization";
        $journalRecord->item_id = $immunization->id;
        $journalRecord->save();

        return response()->json([
            'status'=>'success',
         ]);
    }





}
