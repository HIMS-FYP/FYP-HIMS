<?php
/**
 * Created by PhpStorm.
 * User: charden
 * Date: 6/9/2019
 * Time: 17:04 PM
 */

namespace App\DumbClasses;


class Expenses
{

}