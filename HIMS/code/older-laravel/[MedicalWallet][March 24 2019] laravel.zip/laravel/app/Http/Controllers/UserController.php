<?php

namespace App\Http\Controllers;

use App\ActiveVisit;
use App\User;
use App\Visit;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class UserController extends Controller{

    /**
     * Create a new controller instance.
     * @return void
     */
    public function __construct(){
        //$this->middleware('auth');
    }


    /**
     * Show the application dashboard.
     * @return \Illuminate\Http\Response
     */
    public function index(){
        return redirect()->route('user.visit.current');
    }


    //-------------------------------------------------------------------------------
    //-----------------VISITS -------------------------------------------------------

    public function currentVisit(Request $request){

        if($request->session()->get('availableActiveVisit')){
            $activeVisit = ActiveVisit::where('access_token', $request->session()->get('visit_token')
                )->first();
            $visit= Visit::find($activeVisit->visit_id);
        }else{
            $visit=new Visit();
        }

        return view('user.1_visit')->with(
            [
                'activeWalletTab'=>'visit',
                'currentVisit'=>$visit,
                'availableActiveVisit'=>$request->session()->get('availableActiveVisit'),
                'visitAccessToken'=>$request->session()->get('visit_token') ,
                'showPreviousVisits'=>false,
                'previousVisits'=>[],
            ]);
    }


    public function addNewVisit(Request $request){
        $visit = new Visit();
        $visit->user_id = User::all()->first()->id; //TODO get real ID
        $visit->active = true;
        $visit->save();

        $activeVisit = new ActiveVisit();
        $activeVisit->visit_id =  $visit->id;
        $userId= 670;
        $activeVisit->access_token = strtoupper(str_random(4)) ."0".$userId. strtoupper(str_random(2)) ;
        $activeVisit->save();

        $request->session()->put('availableActiveVisit', true);
        $request->session()->put('visit_token', $activeVisit->access_token );

        return redirect()->route('user.visit.current');
    }

    public function closeVisitForm(Request $request){
        //TODO Test when a session expire
        $request->session()->put('availableActiveVisit', false);
        $request->session()->put('visit_token', null);

        return redirect()->route('user.visit.current');
    }

    public function showPreviousVisits(Request $request){
        $visits = Visit::orderBy('id','DESC')->get();
        return view('user.1_visit')->with(
            [
                'activeWalletTab'=>'visit',
                'currentVisit'=>new Visit(),
                'availableActiveVisit'=>false,
                'visitAccessToken'=>$request->session()->get('visit_token') ,
                'showPreviousVisits'=>true,
                'previousVisits'=>$visits,
            ]);
    }


    public function activatePreviousVisits(Request $request,$visit_id){

        $activeVisit = new ActiveVisit();
        $activeVisit->visit_id =  $visit_id;
        $userId= 670;
        $activeVisit->access_token = strtoupper(str_random(4)) ."0".$userId. strtoupper(str_random(2)) ;
        $activeVisit->save();

        $request->session()->put('availableActiveVisit', true);
        $request->session()->put('visit_token', $activeVisit->access_token );

        return redirect()->route('user.visit.current');
    }




    //-----------------------------------------------------------------------------------
    //-----------------BASIC INFO -------------------------------------------------------


    public function userBasicInfo(){
        return view('user.1_visit')->with(
            [
                'activeWalletTab'=>'visit',
                'editMode'=>'none'
            ]);
    }







}
