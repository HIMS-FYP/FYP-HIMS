
<ul class="nav nav-tabs" role="tablist">


    <li class="nav-item">
        <a class="nav-link <?php echo e($activeWalletTab =="visit"? 'active current-tab':' '); ?> "
           href="<?php echo e(route('hce.patient.consultation')); ?>/<?php echo e($accessToken); ?>">
            <i class="fa fa-clock"> </i>
            Current Visit
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link <?php echo e($activeWalletTab =="basic"? 'active current-tab':' '); ?>"
           href="<?php echo e(route('doctor.user.info.basic')); ?>">
            <i class="fa fa-user"> </i>
            Basic Information
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e($activeWalletTab =="basic"? 'active current-tab':' '); ?>"
           href="<?php echo e(route('doctor.user.background')); ?>">
            <i class="fa fa-heartbeat"> </i>
            Medical Background
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e($activeWalletTab =="journal"? 'active current-tab':' '); ?> "
           href="<?php echo e(route('doctor.user.journal')); ?>">
            <i class="fa fa-calendar-day"> </i>
            Medical Journal
        </a>
    </li>
</ul>