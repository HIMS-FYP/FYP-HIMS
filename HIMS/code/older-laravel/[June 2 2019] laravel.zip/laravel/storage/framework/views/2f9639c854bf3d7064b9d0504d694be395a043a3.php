<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title> DMW User </title>

    <!-- Fonts -->
    <link href="<?php echo e(asset('css/fonts.css')); ?>" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fontawesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/widgets.css')); ?>" rel="stylesheet">

    <style>
        .nav-link.active{
            background: #D1F2EB !important;
            border-color:#D1F2EB !important ;
        }

        .logo-text{
            text-align: center;
            color: #fff;
        }

        .navbar-nav{

            /*background: #ffa23b;*/
        }
        .nav-item-heading{
            border-bottom: 1px solid #fff8b3;
            border-bottom-left-radius: 8px;
            color: #fff;
            padding: 0.2em;
            margin-top: 1em;
            width: 100%;

        }
        .left-menu-link {
            color: #eeeeee !important;
        }


        .visit-heading{
            margin-bottom: 1.8em;
        }

        .current-visit{
            /*border-left: 5px solid #D4AC0D;*/
            padding: 1em;
            border-top-left-radius: 1.4em;
            border-top-right-radius: 1.4em;
        }
        .encounter-item{
            /*border: 1px solid #aaa;*/
            padding: 0.4em;
            margin-bottom: 1.8em;
        }
        .encounter-heading{
            background: #707B7C;
            color: white;
            padding: 0.4em 0.6em 0.1em 0.6em;
            display: inline-block;
            margin: 0;
            border-top-left-radius: 0.5em;
            border-top-right-radius: 0.5em;
        }
        .encounter-heading-holder{
            border-bottom: 3px solid #707B7C;
        }
        .encounter-body{
            border: 2px solid #707B7C;
            padding: 0.5em;
        }
        .btn-sm{
            border-radius: 1em;
            padding: 0.1em 1em;
        }

        .access-token{
            font-size: 1.3em;
            display: inline-block;
            padding: 2px 0.8em;
            margin: 0.1em 0.5em;
            font-family: Consolas, "Liberation Mono", "Courier New", monospace;
        }

        .previous-visits-holder{
            padding: 1em;
        }

        .visit-item {
            background: #EAFAF1;
            padding: 0.8em 1.2em;
            margin-bottom: 3em;
            border-top-right-radius: 1em;
            border-top-left-radius: 1em;
            border-bottom-right-radius: 1em;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        }

        .visit-item p{
            /*color: #7D6608;*/
            color: #000000;
            margin: 0 !important;
            font-size: 1.2em;
        }

        .active-form-nav{
            border-bottom: 3px solid #3498DB;
        }

        .fa-adjust{
            font-size: 0.8em;
        }


        .vital-heading{
            font-size: 1.4em;
            color: #28B463;
        }

        .allergy-heading{
            font-size: 1.4em;
            color: #E74C3C;
        }

        .disease-heading{
            font-size: 1.4em;
            color: #E74C3C;
        }


        .immunization-heading{
            font-size: 1.4em;
            color: #17A589;
        }

        .medical-item{
        }


    </style>

</head>


<body  >

<div id="app">
    <div class="container-fluid">

        <div class="row">

            <?php echo $__env->make('user.components.left-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!--Right Content -->
            <div class="col-lg-9" style="padding-left:0; padding-right: 0;">

                <!-- Top Navigation -->
                <?php echo $__env->make('user.components.top_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <main class="py-4">
                    <div class="container-fluid">
                        <div class="row justify-content-center">

                            <div class="col-md-12">
                                <div class="card">


                                    <div class="card-body" style=" background: #D1F2EB;">

                                                <div class="row current-visit" >

                                                    <!-- Today's Visit heading -->
                                                    <div class="col-12">
                                                        <h2 style=" display: inline-block">
                                                            <i class="fa fa-heartbeat "></i>
                                                            Medical Background
                                                        </h2>



                                                    </div>

                                                    <div  class="col-12 encounter-item"  >
                                                        <div class="row previous-visits-holder">

                                                            <!-- VITALS -->
                                                            <div class="col-md-11 ">

                                                                    <div class="visit-item">
                                                                        <h4> <i class="fa fa-thermometer-half"></i>
                                                                            Vitals
                                                                        </h4>

                                                                        <div class="row">


                                                                            <div class="col-md-4">
                                                                                <ul class="medical-item" style="list-style: none">
                                                                                    <li class="vital-heading">
                                                                                        Weight
                                                                                    </li>
                                                                                    <li>67 kg </li>
                                                                                    <li>Last Recorded <i>  May 2,2019</i> </li>
                                                                                    <li>
                                                                                        <a href="<?php echo e(route('user.info.medical.weight.trend')); ?>/visualization">
                                                                                            Trend</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>

                                                                            <div class="col-md-4">
                                                                                <ul style="list-style: none">
                                                                                    <li class="vital-heading">
                                                                                        Height
                                                                                    </li>
                                                                                    <li> 1.65m </li>
                                                                                    <li>Last Recorded <i>  May 4,2019</i> </li>
                                                                                    <li>
                                                                                        <a href="<?php echo e(route('user.info.medical.weight.trend')); ?>/visualization">
                                                                                            Trend</a>
                                                                                    </li>

                                                                                </ul>
                                                                            </div>


                                                                            <div class="col-md-4">
                                                                                <ul style="list-style: none">
                                                                                    <li class="vital-heading">
                                                                                        Blood type
                                                                                    </li>
                                                                                    <li> B+ </li>
                                                                                    <li>
                                                                                        <a href="#">
                                                                                            Edit</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>

                                                                            <div class="col-md-4">
                                                                                <ul style="list-style: none">
                                                                                    <li class="vital-heading">
                                                                                        Blood pressure
                                                                                    </li>
                                                                                    <li> 120/80 mmHg</li>
                                                                                    <li>Last Recorded <i>  May 4,2019</i> </li>
                                                                                    <li>
                                                                                        <a href="#">
                                                                                            Trend</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>

                                                                            <div class="col-md-4">
                                                                                <ul style="list-style: none">
                                                                                    <li class="vital-heading">
                                                                                        Blood Sugar level
                                                                                    </li>
                                                                                    <li> 120/80 </li>
                                                                                    <li>Last Recorded <i>  May 4,2019</i> </li>
                                                                                    <li>
                                                                                        <a href="#">
                                                                                            Trend</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>

                                                                            <div class="col-md-4">
                                                                                <ul style="list-style: none">
                                                                                    <li class="vital-heading">
                                                                                        Heart rate (Rested)
                                                                                    </li>
                                                                                    <li> 74 bpm </li>
                                                                                    <li>Last Recorded <i>  June 9,2019</i> </li>
                                                                                    <li>
                                                                                        <a href="#">
                                                                                            Trend</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>

                                                                            <div class="col-md-4">
                                                                                <ul style="list-style: none">
                                                                                    <li class="vital-heading">
                                                                                        BMI
                                                                                    </li>
                                                                                    <li> 20 </li>
                                                                                    <li>
                                                                                        From Weight an Height
                                                                                    </li>

                                                                                </ul>
                                                                            </div>

                                                                        </div>

                                                                    </div>
                                                                </div>


                                                            <!-- Diseases & Complications -->
                                                            <div class="col-md-11 ">

                                                                    <div class="visit-item">
                                                                        <h4> <i class="fa fa-user-injured"></i>
                                                                            Syndromes, Diseases, Conditions & Disorders
                                                                        </h4>

                                                                        <div class="nav" style="margin-bottom: 0.6em">
                                                                            <div class="col-12">
                                                                                <a class=" nav-link  btn btn-sm  btn-outline-primary float-right"
                                                                                   href="#">
                                                                                    <i class="fa fa-plus-square"> </i>
                                                                                    Add
                                                                                </a>
                                                                            </div>
                                                                        </div>

                                                                        <div class="row">

                                                                            <div class="col-md-6">
                                                                                <ul style="list-style: none">
                                                                                    <li class="disease-heading">
                                                                                        Asthma
                                                                                        <a href="#">
                                                                                            <i class="fa fa-pencil-alt"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li> Diagnosed: Feb 2006 </li>
                                                                                    <li> 50 / mcg intramuscular injection </li>
                                                                                </ul>
                                                                            </div>

                                                                            <div class="col-md-6">
                                                                                <ul style="list-style: none">
                                                                                    <li class="disease-heading">
                                                                                        High blood pressure
                                                                                        <a href="#">
                                                                                            <i class="fa fa-pencil-alt"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li> Diagnosed: May 2004</li>
                                                                                    <li>50 / mcg intramuscular injection </li>
                                                                                </ul>
                                                                            </div>

                                                                            <div class="col-md-6">
                                                                                <ul style="list-style: none">
                                                                                    <li class="disease-heading">
                                                                                        Diabetes
                                                                                        <a href="#">
                                                                                            <i class="fa fa-pencil-alt"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li> Diagnosed: May 2000</li>
                                                                                    <li>50 / mcg intramuscular injection </li>
                                                                                </ul>
                                                                            </div>

                                                                            <div class="col-md-6">
                                                                                <ul style="list-style: none">
                                                                                    <li class="disease-heading">
                                                                                        Sickle cell anaemia
                                                                                        <a href="#">
                                                                                            <i class="fa fa-pencil-alt"></i>
                                                                                        </a>
                                                                                    </li>
                                                                                    <li> Diagnosed: May 2000</li>
                                                                                    <li>50 / mcg intramuscular injection </li>
                                                                                </ul>
                                                                            </div>

                                                                        </div>



                                                                    </div>
                                                                </div>


                                                            <!-- Current Medications -->
                                                            <div class="col-md-11 ">

                                                                    <div class="visit-item">
                                                                        <h4> <i class="fa fa-pills"></i>
                                                                            Current Medications
                                                                        </h4>

                                                                        <div class="row">

                                                                            <div class="col-md-6">
                                                                                <ul style="list-style: none">
                                                                                    <li class="immunization-heading">
                                                                                        ALU
                                                                                    </li>
                                                                                    <li> Diagnosed: Feb 2006 </li>
                                                                                    <li> 50 / mcg intramuscular injection </li>
                                                                                </ul>
                                                                            </div>

                                                                            <div class="col-md-6">
                                                                                <ul style="list-style: none">
                                                                                    <li class="immunization-heading">
                                                                                        High blood pressure
                                                                                    </li>
                                                                                    <li> Diagnosed: May 2004</li>
                                                                                    <li>50 / mcg intramuscular injection </li>
                                                                                </ul>
                                                                            </div>

                                                                            <div class="col-md-6">
                                                                                <ul style="list-style: none">
                                                                                    <li class="immunization-heading">
                                                                                        Diabetes
                                                                                    </li>
                                                                                    <li> Diagnosed: May 2000</li>
                                                                                    <li>50 / mcg intramuscular injection </li>
                                                                                </ul>
                                                                            </div>

                                                                            <div class="col-md-6">
                                                                                <ul style="list-style: none">
                                                                                    <li class="immunization-heading">
                                                                                        Sickle cell anaemia
                                                                                    </li>
                                                                                    <li> Diagnosed: May 2000</li>
                                                                                    <li>50 / mcg intramuscular injection </li>
                                                                                </ul>
                                                                            </div>

                                                                        </div>



                                                                    </div>
                                                                </div>


                                                            <!-- Allergies -->
                                                            <div class="col-md-11 ">

                                                                <div class="visit-item">
                                                                    <h4> <i class="fa fa-frown-open"></i>
                                                                        Allergies
                                                                    </h4>

                                                                    <div class="row">

                                                                        <div class="col-md-4">
                                                                            <ul style="list-style: none">
                                                                                <li class="allergy-heading">
                                                                                    Bee sting
                                                                                    <a href="#">
                                                                                        <i class="fa fa-pencil-alt"></i>
                                                                                    </a>
                                                                                </li>
                                                                                <li> Reaction: Anaphylactic Shock </li>
                                                                                <li> Severity: Severe </li>
                                                                            </ul>
                                                                        </div>

                                                                        <div class="col-md-4">
                                                                            <ul style="list-style: none">
                                                                                <li class="allergy-heading">
                                                                                    Penicillin
                                                                                    <a href="#">
                                                                                        <i class="fa fa-pencil-alt"></i>
                                                                                    </a>
                                                                                </li>
                                                                                <li> Reaction: Skin itches </li>
                                                                                <li> Severity: Moderate </li>
                                                                            </ul>
                                                                        </div>

                                                                        <div class="col-md-4">
                                                                            <ul style="list-style: none">
                                                                                <li class="allergy-heading">
                                                                                    Codeine
                                                                                    <a href="#">
                                                                                        <i class="fa fa-pencil-alt"></i>
                                                                                    </a>
                                                                                </li>
                                                                                <li> Reaction: Shortness of Breath </li>
                                                                                <li> Severity: Severe </li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>


                                                            <!-- Immunizations -->
                                                            <div class="col-md-11 ">

                                                                <div class="visit-item">
                                                                    <h4> <i class="fa fa-syringe"></i>
                                                                        Immunizations
                                                                    </h4>

                                                                    <div class="row">

                                                                        <div class="col-md-6">
                                                                            <ul style="list-style: none">
                                                                                <li class="immunization-heading">
                                                                                    Influenza Virus Vaccine
                                                                                    <a href="#">
                                                                                        <i class="fa fa-pencil-alt"></i>
                                                                                    </a>
                                                                                </li>
                                                                                <li> PRESCRIBED: April 2000 </li>
                                                                                <li> 50 / mcg intramuscular injection </li>
                                                                            </ul>
                                                                        </div>

                                                                        <div class="col-md-6">
                                                                            <ul style="list-style: none">
                                                                                <li class="immunization-heading">
                                                                                    Tetanus and diphtheria toxoids
                                                                                    <a href="#">
                                                                                        <i class="fa fa-pencil-alt"></i>
                                                                                    </a>
                                                                                </li>
                                                                                <li> COMPLETED: May 2001</li>
                                                                                <li>50 / mcg intramuscular injection </li>
                                                                            </ul>
                                                                        </div>

                                                                    </div>



                                                                </div>
                                                            </div>


                                                            <!-- Vitamins and De-worming -->
                                                            <div class="col-md-11 ">

                                                                <div class="visit-item">
                                                                    <h4> <i class="fa fa-syringe"></i>
                                                                        Vitamins and De-Worming
                                                                    </h4>

                                                                    <div class="row">

                                                                        <div class="col-md-6">
                                                                            <ul style="list-style: none">
                                                                                <li class="immunization-heading">
                                                                                    Influenza Virus Vaccine
                                                                                    <a href="#">
                                                                                        <i class="fa fa-pencil-alt"></i>
                                                                                    </a>
                                                                                </li>
                                                                                <li> PRESCRIBED: April 2000 </li>
                                                                                <li> 50 / mcg intramuscular injection </li>
                                                                            </ul>
                                                                        </div>

                                                                        <div class="col-md-6">
                                                                            <ul style="list-style: none">
                                                                                <li class="immunization-heading">
                                                                                    Tetanus and diphtheria toxoids
                                                                                    <a href="#">
                                                                                        <i class="fa fa-pencil-alt"></i>
                                                                                    </a>
                                                                                </li>
                                                                                <li> COMPLETED: May 2001</li>
                                                                                <li>50 / mcg intramuscular injection </li>
                                                                            </ul>
                                                                        </div>

                                                                    </div>



                                                                </div>
                                                            </div>


                                                        </div>
                                                    </div>

                                                </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>

        </div>
    </div>
</div>


<!-- Scripts -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" defer></script>


</body>
</html>
