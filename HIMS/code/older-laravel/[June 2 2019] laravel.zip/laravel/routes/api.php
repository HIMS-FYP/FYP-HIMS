<?php

use Illuminate\Http\Request;


#test
Route::get('/user', function ( ) {
    return "API reached";
});



#1.2 Vital Signs
Route::get('/user/signs/get/{user_id?}', 'UserControllerAPI@getVitalSignRecords');
Route::post('/user/signs/post', 'UserControllerAPI@saveNewVitalSignRecord');

#1.2 Medication
Route::get('/user/medication/get/{user_id?}', 'UserControllerAPI@getMedications');
Route::post('/user/medication/post', 'UserControllerAPI@saveMedications');

#1.3 allergies
Route::get('/user/allergy/get/{user_id?}', 'UserControllerAPI@getAllergies');
Route::post('/user/allergy/post', 'UserControllerAPI@saveNewAllergy');

#1.4 immunization
Route::get('/user/immunization/get/{user_id?}', 'UserControllerAPI@getImmunizations');
Route::post('/user/immunization/post', 'UserControllerAPI@saveNewImmunization');




