<!--Left Navigation -->
<div class="col-lg-3" style="background: #27AE60 !important; min-height: 100vh;  padding-left:0; padding-right: 0; ">

    <div style="padding: 1em; margin-top: 2em">
        <h2 class="logo-text">
            <i class="fa fa-wallet"> </i>
            <b>MW Reader</b>
        </h2>
    </div>

    <div style="padding: 1em; " >

        <h3 class="nav-item-heading">Wallets</h3>

        <li class="nav-item   list-unstyled">
            <a class="nav-link left-menu-link" href="#">
                <i class="fa fa-clock"></i>
                History
            </a>
        </li>


        <h3 class="nav-item-heading">Preferences </h3>

        <li class="nav-item  list-unstyled">
            <a class="nav-link left-menu-link" href="#">
                <i class="fa fa-cog"> </i>
                My Profile
            </a>
        </li>
        <li class="nav-item  list-unstyled">
            <a class="nav-link left-menu-link " href="#">
                <i class="fa fa-cog"> </i>
                Change password
            </a>
        </li>
    </div>
</div>