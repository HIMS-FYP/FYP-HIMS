<!--Left Navigation -->
<div class="col-lg-3" style="background: #27AE60 !important; min-height: 100vh;  padding-left:0; padding-right: 0; ">

    <div style="padding: 1em; margin-top: 2em">
        <h2 class="logo-text">
            <i class="fa fa-wallet"> </i>
            <b>DMWallet</b>
        </h2>
    </div>

    <div style="padding: 1em; " >

        <!-- Group 1 Menus-->
        <h3 class="nav-item-heading">Wallets</h3>



        <li class="nav-item   list-unstyled">
            <a class="nav-link left-menu-link <?php echo e($activeLeftNav=='visits'? 'active-left-nav' : ''); ?>"
               href="<?php echo e(route('user')); ?>">
                <i class="fa fa-file-medical-alt"></i>
                Visits Forms
            </a>
        </li>

        <li class="nav-item   list-unstyled">
            <a class="nav-link left-menu-link <?php echo e($activeLeftNav=='basic'? 'active-left-nav' : ''); ?>"
               href="<?php echo e(route('user.info.basic')); ?>">
                <i class="fa fa-user"></i>
                Basic Information
            </a>
        </li>

        <li class="nav-item   list-unstyled">
            <a class="nav-link left-menu-link <?php echo e($activeLeftNav=='medical'? 'active-left-nav' : ''); ?>"
               href="<?php echo e(route('user.info.medical')); ?>">
                <i class="fa fa-heartbeat"></i>
                Medical Background
            </a>
        </li>

        <li class="nav-item   list-unstyled">
            <a class="nav-link left-menu-link <?php echo e($activeLeftNav=='journal'? 'active-left-nav' : ''); ?>"
               href="<?php echo e(route('user.info.journal')); ?>">
                <i class="fa fa-calendar-day"></i>
                Medical Journal
            </a>
        </li>


        <!-- Group 2 Menus-->
        <h3 class="nav-item-heading">Preferences </h3>

        <li class="nav-item  list-unstyled">
            <a class="nav-link left-menu-link " href="#">
                <i class="fa fa-cog"> </i>
                Change password
            </a>
        </li>
    </div>
</div>