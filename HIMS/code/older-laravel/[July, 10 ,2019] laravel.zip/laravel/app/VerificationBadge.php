<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VerificationBadge extends Model
{
    //
}
