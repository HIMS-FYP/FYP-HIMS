<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->

    <!-- Fonts -->
    <link href="<?php echo e(asset('css/fonts.css')); ?>" rel="stylesheet">

    <!-- Styles -->

    <style>


        .section-heading h5 {
            color: #414141;
            padding: 4px 1em;
            margin: 0
        }



        /** [[Start]] Service Form **/
        .visit-holder {
            /*padding: 2em 2em ;*/
        }

        .current-visit {
            /*border-left: 5px solid #D4AC0D;*/
            margin: 0.5em;
            padding: 1em;
            background: #ffffff;
        }

        .encounter-item {
            /*border: 1px solid #aaa;*/
            padding: 0.4em;
            margin-bottom: 1.8em;
        }

        .encounter-heading {
          //  background: #707B7C;
            color: black;
            padding: 0;
            display: inline-block;
            margin: 0;
            font-size: 1.4em;
            text-decoration: underline;
            border-top-left-radius: 0.5em;
            border-top-right-radius: 0.5em;
        }


        .encounter-body {
            padding: 0.5em 2em;
        }

        .encounter-data {
            margin: 0.2em 0 0.5em 0.5em !important;
        }

        .btn-sm {
            border-radius: 1em;
            padding: 0.1em 1em;
        }

        .investigation-item {
            background: #EAEDED;
            border-left: 6px solid #F4D03F;
            margin: 1em 0.5em 3.2em 0.5em;
            padding-top: 0.8em;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);

        }


        .encounter-data {
            margin: 0;
            font-size: 1.2em;
            font-family: Consolas, "Liberation Mono", "Courier New", monospace;
        }

        .encounter-data-number {
             padding: 0 0.4em;
            border-radius: 0.5em;
            font-style: normal;
            font-size: 0.9em;
        }

        .investigation-item-caret {
            color: #F4D03F;
            font-size: 1.3em;
        }

        .prescription-item {
            margin: 0;
            font-size: 1.2em;
        }

        .list-indicator {
            margin: 0 0em;
            padding: 0 0.5em;
            background: #000;
            color: white;
            border-radius: 1em;
        }

        .page-break {
            page-break-after: always;
        }

        .detail-p-heading{
            margin: 0;
            text-decoration: underline;
        }
        .detail-p-item{
            font-size: 1em;
            padding-right: 1em;
            margin: 2px;
        }
        /** [[End]] Service Form **/

        /*** Payment ***/
        .payment-subheading{
            font-size: 1.1em;
            font-weight: bold;
            font-style: italic;
        }
        /**** [[end]] payments ***/
    </style>

</head>


<body>

<div class="visit-holder">
    <div class="row current-visit">

        <!-- Today's Visit Accounts Summary -->
        <div class="col-12">


            <!-- Contacts -->
            <div style="padding: 1em">
                <h3 class="detail-p-heading">
                     Contacts
                </h3>

                <p class="detail-p-item">
                       Patient Name <strong> <?php echo e($visit->name); ?> </strong>
                </p>
                <p class="detail-p-item">
                    Wallet Token <strong> <?php echo e($visit->dmw_token); ?> </strong>
                </p>
                <p class="detail-p-item">
                    Phone #1 <strong> <?php echo e($visit->phone_1); ?> </strong>
                </p>
                <p class="detail-p-item">
                    Phone #2 <strong> <?php echo e($visit->phone_1); ?> </strong>
                </p>
                <p class="detail-p-item">
                    Residence  <strong>  <?php echo e($visit->region); ?>,  <?php echo e($visit->district); ?>,
                        <?php echo e($visit->ward); ?>,   <?php echo e($visit->street); ?> </strong>
                </p>

            </div>

            <!-- Form Details -->
            <div style="padding: 1em">
                <h3 class="detail-p-heading">
                    Form info
                </h3>

                <p class="detail-p-item">
                    Serial N<u>o</u> <strong> <?php echo e($visit->serial_number); ?> </strong>
                </p>

                <p class="detail-p-item">
                    Consultation fee  <strong>  <?php echo e($visit->consultation_fee); ?> </strong>
                </p>
                <p class="detail-p-item">
                    Payment type <strong> <?php echo e($visit->payment_type); ?> </strong>
                </p>
                <?php if( !(empty($visit->nhif_card_number))): ?>
                    <p class="detail-p-item">
                        NHIF Card Number <strong> <?php echo e($visit->nhif_card_number); ?> </strong>
                    </p>
                <?php endif; ?>
                <p class="detail-p-item">
                    Created  <strong>  <?php echo e($visit->created_at); ?>  </strong>
                </p>

            </div>

        </div>





        <!-- Encounter 1  Chief Complaint / Symptoms-->
        <div id="symptom" class="col-12 encounter-item">
            <div class="row ">
                <!-- Chief Complaint heading --->
                <div class="col-12 ">
                    <div class="encounter-heading-holder">
                        <h4 class="encounter-heading">
                            <i class="fa fa-frown"> </i>
                            Chief Complaint / Symptoms
                        </h4>
                    </div>
                </div>

                <!-- Chief Complaint  body -->
                <div class="col-12 ">
                    <div class="encounter-body">
                        <div>
                            <?php $__currentLoopData = $encounters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $encounter->encounter_code == 001 ): ?>
                                    <ol style="margin: 0">
                                    <?php $__currentLoopData = $encounter->encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="encounter-data">
                                            <i class="fa fa-frown-open"
                                               style="color: #E74C3C; font-size: 0.9em"> </i>
                                            <?php echo e($encounterData->text_1); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>

            </div>
        </div>


        <!-- Encounter 6.0 Final Diagnosis -->
        <div id="finalDiagnosis" class="col-12 encounter-item">
            <div class="row">
                <!--Advice heading --->
                <div class="col-12 ">
                    <div class="encounter-heading-holder">
                        <h4 class="encounter-heading">
                            <i class="fa fa-clipboard-list"> </i>
                            Final Diagnoses
                        </h4>
                    </div>
                </div>

                <!--   Final Diagnosis body -->
                <div class="col-12 ">
                    <div class="encounter-body">
                        <div>
                            <?php $__currentLoopData = $encounters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $encounter->encounter_code == 006 ): ?>
                                    <ol>
                                        <?php $__currentLoopData = $encounter->encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="encounter-data">
                                                <i class="fa fa-check"> </i>
                                                <?php echo e($encounterData->text_1); ?>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                    </div>
                </div>

            </div>
        </div>


        <!-- Encounter 4 Prescriptions -->
        <div id="prescription" class="col-12 encounter-item">
            <div class="row ">
                <!--Prescriptions heading --->
                <div class="col-12 ">
                    <div class="encounter-heading-holder">
                        <h4 class="encounter-heading">
                            <i class="fa fa-pills"> </i>
                            Prescriptions
                        </h4>
                    </div>
                </div>

                <!-- Prescriptions body -->
                <div class="col-12 ">
                    <div class="encounter-body">

                        <div>
                            <?php $__currentLoopData = $encounters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $encounter->encounter_code == 004 ): ?>
                                    <ol>
                                        <?php $__currentLoopData = $encounter->encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="prescription-item">
                                                <i class="fa fa-capsules"> </i>
                                                <?php echo e($encounterData->text_1); ?>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                    </div>
                </div>

            </div>
        </div>

        <div class="page-break"></div>

        <!-- Encounter 3  Investigations / Lab tests -->
        <div id="investigation" class="col-12 encounter-item">
            <div class="row ">
                <!-- Test/Investigation Heading -->
                <div class="col-12 ">
                    <div class="encounter-heading-holder">
                        <h4 class="encounter-heading">
                            <i class="fa fa-microscope"> </i>
                            Investigations/Lab tests
                        </h4>
                    </div>
                </div>

                <!-- Test/Investigations body -->
                <div class="col-12 ">
                    <div class="encounter-body">

                        <!-- List of Tests/Investigations Datas-->
                        <div>
                            <?php $__currentLoopData = $encounters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $encounter->encounter_code == 003 ): ?>
                                    <ol>
                                    <?php $__currentLoopData = $encounter->encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i =>  $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li class=" "
                                             style="padding-bottom: 0.4em">
                                            <!-- Test/Investigation Description -->
                                            <p class="encounter-data">
                                                <i class="fa investigation-item-caret"> </i>
                                                <i class="encounter-data-number">
                                                    Test ID: <b>LB-046-<?php echo e($encounterData->id); ?></b>
                                                </i>
                                                <span style="padding-left: 1em"> <?php echo e($encounterData->text_1); ?> </span>

                                            </p>

                                            <!-- ====PAYMENT-PAYMENT-PAYMENT======= -->
                                            <!-- PAYMENT STATUS-->
                                            <?php if( $encounterData->is_fee_paid): ?>
                                                <div style="margin-left: 0.8em;padding: 0.4em;">

                                                    <p class="status-paragraph">
                                                        <strong>
                                                            <i class="fa fa-money-bill-alt"></i>
                                                            Test Payment Status:
                                                        </strong>
                                                        <span style="color: #38c172 ">
                                                        <i class="fa fa-check-circle"></i>
                                                        Paid ,
                                                    </span>
                                                        <strong>
                                                            Tsh <?php echo e($encounterData->fee_amount); ?>

                                                        </strong>
                                                    </p>
                                                </div>
                                        <?php else: ?>

                                        <?php endif; ?>


                                        </li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>

            </div>
        </div>

        <!-- Encounter 2  Physical examination-->
        <div id="examination" class="col-12 encounter-item">
            <div class="row ">
                <!--examination heading --->
                <div class="col-12 ">
                    <div class="encounter-heading-holder">
                        <h4 class="encounter-heading">
                            <i class="fa fa-stethoscope"> </i>
                            Physical examination findings
                        </h4>
                    </div>
                </div>

                <!-- examination body -->
                <div class="col-12 ">
                    <div class="encounter-body">

                        <div>
                            <?php $__currentLoopData = $encounters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $encounter->encounter_code == 002 ): ?>
                                    <?php $__currentLoopData = $encounter->encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="encounter-data">
                                            <i class="fa fa-caret-right"> </i>
                                            <?php echo e($encounterData->text_1); ?>

                                        </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>

            </div>
        </div>

        <!-- Encounter 7 Advice  -->
        <div id="advice" class="col-12 encounter-item">
            <div class="row">
                <!--Advice heading --->
                <div class="col-12 ">
                    <div class="encounter-heading-holder">
                        <h4 class="encounter-heading">
                            <i class="fa fa-clipboard-list"> </i>
                            Advice
                        </h4>
                    </div>
                </div>

                <!-- Advice body -->
                <div class="col-12 ">
                    <div class="encounter-body">
                        <div>
                            <?php $__currentLoopData = $encounters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $encounter->encounter_code == 005 ): ?>
                                    <?php $__currentLoopData = $encounter->encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="encounter-data">
                                            <i class="fa fa-check"> </i>
                                            <?php echo e($encounterData->text_1); ?>

                                        </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>

            </div>
        </div>

        <div class="page-break"></div>

        <!-- Expenses  -->
        <div  class="col-12 encounter-item" style="border: 1px solid #222222">
            <div class="row">
                <!--Advice heading --->
                <div class="col-12 ">
                    <div class="encounter-heading-holder">
                        <h4 class="encounter-heading">
                            <i class="fa fa-clipboard-list"> </i>
                            Expenses
                        </h4>
                    </div>
                </div>

                <!-- Advice body -->
                <div class="col-12 ">
                    <div class="encounter-body">
                        <div>


                            <p class="payment-subheading">Consultation </p>

                            <p class="encounter-data">
                                <i class="fa fa-check"> </i>
                                Consultation fee
                               <strong><?php echo e($visit->consultation_fee); ?> </strong>
                            </p>

                            <div style="height: 1px; width: 100%; background: #b9bbbe"> </div>


                            <?php $__currentLoopData = $encounters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if( $encounter->encounter_code == 003 ): ?>

                                    <p class="payment-subheading">Lab Tests </p>

                                    <?php $__currentLoopData = $encounter->encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($encounterData->is_fee_paid): ?>
                                        <p class="encounter-data">
                                            <i class="fa fa-check"> </i>
                                            <?php echo e($encounterData->text_1); ?>

                                            <strong> <?php echo e($encounterData->fee_amount); ?></strong>
                                        </p>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div style="height: 1px; width: 100%; background: #b9bbbe"> </div>
                                <?php endif; ?>

                                <?php if( $encounter->encounter_code == 004 ): ?>
                                     <p class="payment-subheading">Prescriptions </p>

                                    <?php $__currentLoopData = $encounter->encounterDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encounterData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($encounterData->is_fee_paid): ?>
                                            <p class="encounter-data">
                                                <i class="fa fa-check"> </i>
                                                <?php echo e($encounterData->text_1); ?>

                                               <strong> <?php echo e($encounterData->fee_amount); ?> </strong>
                                            </p>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div style="height: 1px; width: 100%; background: #b9bbbe"> </div>
                                    <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div style="height: 3px; width: 100%; background: #b9bbbe"> </div>

                            <p class="payment-subheading" style="font-size: 1.3em">
                                Total
                            </p>

                            <p class="encounter-data" style="font-size: 1.5em">
                                <strong><?php echo e($expenses->totalExpenses); ?> </strong>
                            </p>


                        </div>

                    </div>
                </div>

            </div>
        </div>

    </div>
</div>

</body>
</html>
